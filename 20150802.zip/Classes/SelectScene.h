#ifndef __SELECTSCENE_SCENE_H__
#define __SELECTSCENE_SCENE_H__

#include "cocos2d.h"
#include "Actor.h"
#include "SimpleAudioEngine.h"
using namespace CocosDenshion;

#define SELECT_MUSIC_FILE  "bgm/0.mp3"
#define SELECT_BG_FILE     "img/bg/bg02.png"
#define SELECT_BUTTON_FILE  "img/button/button01.png"
#define GAME_MAP  "img/bg/level1.tmx"

class SelectScene : public cocos2d::Layer
{
private:
	Actor* player;
public:
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene();

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
    
    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
	//void onKeyPressed(EventKeyboard::KeyCode keyCode, Event* event);
    // implement the "static create()" method manually
    CREATE_FUNC(SelectScene);
};

#endif // __HELLOWORLD_SCENE_H__
