#include "GameLayer.h"
GameLayer::GameLayer() {
	this->scheduleUpdate();
}
GameLayer::~GameLayer() { }

bool GameLayer::init() {	
	//TMX��ͼ
	_map = TMXTiledMap::create("img/bg/RoundFirst.tmx");
	locX = 0;
	//_map -> setScale(2);
	_edge = _map->layerNamed("edge");
	_wall = _map->layerNamed("walls");
	_hazard = _map->layerNamed("final");
	this -> addChild(_map, 1);

	//Ϊ��ͼ������������
	CreateBox();
	
	/***************
	 *                  player      wall       monster     props     border   edge   Attack
	 *  Category          1          2          4           8         16       32      64
		ContactTest      14          5         99           1         0        4       4
		Collision        18         15          2           2         1        0       0
	 ****************/
	
	//����һ�����
	player = Player::create();
	player -> setPosition(Vec2(64,160));
	player->setTag(PLAYER_TAG);
	this -> addChild(player, 2);

	//���ӹ���
	CreateMonster();

	//���̼�����
	auto listener = EventListenerKeyboard::create();
	listener->onKeyPressed = CC_CALLBACK_2(GameLayer::onKeyPressed, this);
	listener->onKeyReleased = CC_CALLBACK_2(GameLayer::onKeyReleased, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);

	//��ײ������
	auto physicslistener = EventListenerPhysicsContact::create();
	physicslistener->onContactBegin = CC_CALLBACK_1(GameLayer::onContactBegin, this);
	physicslistener->onContactSeperate = CC_CALLBACK_1(GameLayer::onContactSeperate, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(physicslistener, this);


	return true;
}
void GameLayer::onKeyPressed(EventKeyboard::KeyCode keyCode, Event* event) {
    if(MOVE_RIGHT == keyCode) {
		player -> position = 1;  player -> Run();
	} else if(MOVE_LEFT == keyCode) {
		player -> position = -1; player -> Run();
	} else if(JUMP == keyCode) {
		player -> Jump();
	} else if(ATTACK == keyCode) {
		player -> Attack();
	} else if(EventKeyboard::KeyCode::KEY_ESCAPE == keyCode) {
		Size visibleSize = Director::getInstance()->getVisibleSize();
		RenderTexture *renderTexture = CCRenderTexture::create(visibleSize.width,visibleSize.height);
		renderTexture->begin(); 
		this->getParent()->visit();
		renderTexture->end();
		Director::sharedDirector()->pushScene(GamePauseScene::createScene(renderTexture));
	}
}

void GameLayer::onKeyReleased(EventKeyboard::KeyCode keyCode, Event* event) {
	if((EventKeyboard::KeyCode::KEY_D == keyCode && player -> position == 1) ||
		(EventKeyboard::KeyCode::KEY_A == keyCode && player -> position == -1)) {
		player -> StopRunning();
	}
}

//��ײ���ص�����
bool GameLayer::onContactBegin(const PhysicsContact& contact) {
	auto spriteA = (Sprite*)contact.getShapeA()->getBody()->getNode();                 
    auto spriteB = (Sprite*)contact.getShapeB()->getBody()->getNode();
	auto data    = contact.getContactData() -> normal;
	if (spriteA && spriteB) {
		//����������ײ
		if((spriteA -> getTag() == PLAYER_TAG && spriteB -> getTag() == WALL_TAG) ||
			(spriteB -> getTag() == PLAYER_TAG && spriteA -> getTag() == WALL_TAG)) {
			if(data.y > 0.5 && data.y < 1.5)
				player -> onGround = true;
		}
		//�����������ײ
		else if((spriteA -> getTag() == MONSTER_TAG && spriteB -> getTag() == WALL_TAG) ||
			(spriteB -> getTag() == MONSTER_TAG && spriteA -> getTag() == WALL_TAG)) {
			if(data.y > 0.5 && data.y < 1.5) {
				if(spriteA -> getTag() == MONSTER_TAG) 
					((Monster*)spriteA) -> onGround = true;
				else
					((Monster*)spriteB) -> onGround = true;
			}
		}
		else if((spriteA -> getTag() == PLAYER_TAG && spriteB -> getTag() == HAZARD_TAG) ||
			(spriteB -> getTag() == PLAYER_TAG && spriteA -> getTag() == HAZARD_TAG))
			   log("collision");

		//�������Ե��ײ
		else if((spriteA -> getTag() == MONSTER_TAG && spriteB -> getTag() == EDGE_TAG) ||
			(spriteB -> getTag() == MONSTER_TAG && spriteA -> getTag() == EDGE_TAG)) {
				if(spriteA -> getTag() == MONSTER_TAG) {
					if(!(((Monster*)spriteA) -> isActive)) {
						((Monster*)spriteA) -> position *= -1;
						((Monster*)spriteA) -> Run();
					}
				}
				else { 
					if(!(((Monster*)spriteB) -> isActive)) {
						((Monster*)spriteB) -> position *= -1;
						((Monster*)spriteB) -> Run();
					}
				}
		}
		//��������ҵ���ײ
		else if((spriteA -> getTag() == PLAYER_TAG && spriteB -> getTag() == MONSTER_TAG) ||
			(spriteB -> getTag() == PLAYER_TAG && spriteA -> getTag() == MONSTER_TAG)) {
				Monster* mon;
				if(spriteA -> getTag() == PLAYER_TAG) {
					mon = (Monster*)spriteB;
				} else {
					mon = (Monster*)spriteA;
				}
				player->life -= mon->power - player->defence;
				//(GuiLayer*)(this->getParent()->getChildByTag(20))
				if(player->life <= 0) {
					player->StopRunning();
					//player->removeFromPhysicsWorld();
					//player->Status = Actor::status::dead;
					//gameover
				} else {
					player->HitBack(player->getPositionX() - mon->getPosition().x);
				}
		}
		//��������ҹ�����Χ����ײ
		else if((spriteA -> getTag() == ATTACK_TAG && spriteB -> getTag() == MONSTER_TAG) ||
			(spriteB -> getTag() == ATTACK_TAG && spriteA -> getTag() == MONSTER_TAG)) {
				if(spriteA -> getTag() == MONSTER_TAG) {
					((Monster*)spriteA) -> isInrange = true;
				} else {
					((Monster*)spriteB) -> isInrange = true;
				}
		}
		//��������ҹ�����Χ����ײ
		else if((spriteA -> getTag() == PROP_TAG && spriteB -> getTag() == PLAYER_TAG) ||
			(spriteB -> getTag() == PROP_TAG && spriteA -> getTag() == PLAYER_TAG)) {
				Prop* prop;
				if(spriteA -> getTag() == PLAYER_TAG) {
					prop = (Prop*)spriteB;
				} else {
					prop = (Prop*)spriteA;
				}
				player -> AddActorValue( prop->value );
				prop -> removeProp();
		}
    }
	return true;
}
void GameLayer::onContactSeperate(const PhysicsContact& contact) {
	auto spriteA = (Sprite*)contact.getShapeA()->getBody()->getNode();                 
    auto spriteB = (Sprite*)contact.getShapeB()->getBody()->getNode();
	auto data    = contact.getContactData() -> normal;
	if((spriteA -> getTag() == ATTACK_TAG && spriteB -> getTag() == MONSTER_TAG) ||
			(spriteB -> getTag() == ATTACK_TAG && spriteA -> getTag() == MONSTER_TAG)) {
			if(spriteA -> getTag() == MONSTER_TAG) {
				((Monster*)spriteA) -> isInrange = false;
			} else {
				((Monster*)spriteB) -> isInrange = false;
			}	
	}

}
//���ӹ���
void GameLayer::CreateMonster() {
	TMXLayer* _monster = _map -> layerNamed("monster");
	for(int i=0; i < (int)(_map->getMapSize().height); i++)  {
		for(int j=0; j < (int)(_map->getMapSize().width); j++) {
			auto tile = _monster -> getTileAt(Vec2(j,i));
			if(tile) {
				//����һ������
				auto monster =  Monster::create();
				monster -> player = player;
				monster -> setPosition(Vec2(tile->getPositionX(),tile->getPositionY()));
				monster -> setTag(MONSTER_TAG);
				this -> addChild(monster, 1);
			}
		}
	}
}

//ΪTMX��ͼ������������
void GameLayer::CreateBox() {
	for(int i=0; i < (int)(_map->getMapSize().height); i++) {
		int num = 0;
		Sprite* tmp = NULL;
		for(int j=0; j < (int)(_map->getMapSize().width); j++) {
			auto tile = _wall->getTileAt(Vec2(j,i));
			auto edge = _edge->getTileAt(Vec2(j,i));
			//auto tile2 = _hazard->getTileAt(Vec2(i,j));
			if(tile) {
				num ++;
				if(tmp == NULL)	tmp = tile;
			} else if(num != 0) {
				CreateBoxForTile(tmp, WALL_TAG, num, Vec3(2,5,15));
				num = 0;
				tmp = NULL;
			}
			if(edge) {
				CreateBoxForTile(edge, EDGE_TAG, 1, Vec3(32,4,0));
			}
		}
		if(tmp != NULL) {
			CreateBoxForTile(tmp, WALL_TAG, num, Vec3(2,5,15));
			num = 0;
			tmp = NULL;
		}
	}
}
//Ϊһ����Ƭ������������
void GameLayer::CreateBoxForTile(Sprite* tile, int tag, int num, Vec3 bitmask) {
	tile -> setPositionX(tile -> getPositionX()+ tile -> getContentSize().width/2);
	tile -> setPositionY(tile -> getPositionY()+ tile -> getContentSize().height/2);
	tile -> setTag(tag);
	auto physicsbody = PhysicsBody::createEdgeBox(Size(_map->getTileSize().width*num,_map->getTileSize().height),
	PhysicsMaterial(0.0f, 0.0f, 0.0f));
	physicsbody -> setGravityEnable(false);
	physicsbody -> setDynamic(false);
	physicsbody -> setCategoryBitmask(bitmask.x);
	physicsbody -> setContactTestBitmask(bitmask.y);
	physicsbody -> setCollisionBitmask(bitmask.z); 
	tile->setPhysicsBody(physicsbody);

	physicsbody -> setPositionOffset(Vec2(_map->getTileSize().width * (num - 1) / 2, 0));

}
//�ӵ����
void GameLayer::setViewpointCenter(cocos2d::Point pos, float dt) {
	Size visibleSize = Director::getInstance()->getVisibleSize();
	//�޶���ɫ���ܳ�������
	if(pos.x > visibleSize.width/2) {
		locX -= pos.x - visibleSize.width/2;
		float offset = locX;
		if(locX < visibleSize.width - _map->getMapSize().width * _map->getTileSize().width) {
			locX = visibleSize.width - _map->getMapSize().width * _map->getTileSize().width ;
		}
		offset = locX-offset;
		_map->setPositionX(locX);
		player -> setPositionX(visibleSize.width/2 + offset);

		Vector<Node*> vec = getChildren();
		for(int i=0; i < vec.size(); i++) {
			if(vec.at(i)->getTag() == MONSTER_TAG || vec.at(i)->getTag() == PROP_TAG)
				vec.at(i) -> setPositionX(visibleSize.width/2 + offset + (vec.at(i)->getPositionX() - pos.x));
		}
	}
}

void GameLayer::update(float dt) {
	this->setViewpointCenter(player->getPosition(), dt);
}




