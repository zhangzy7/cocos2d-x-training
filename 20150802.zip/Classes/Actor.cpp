#include "Actor.h"
USING_NS_CC; 

Actor::Actor() {
	position = 0;
	VelocityX = 100;
	isAble = true;
}
Actor::~Actor() {
}
//����ͼƬ������Ӣ��
void Actor::InitActorSprite(char *actor_name, Rect rect) {
	//��ʼ������
	Actor_name = actor_name;
	texture = TextureCache::sharedTextureCache()->addImage(Actor_name);
	textureRect = rect;
	Status = currentStatus = stop;

	//������������
	physicsbody = PhysicsBody::createBox(Size(rect.getMaxX() - 15, rect.getMaxY() - 15),
		PhysicsMaterial(0.1f, 0.0f, 0.0f));  //1��density���ܶȣ�2��restiution�����ԣ�3��friction��Ħ������
	physicsbody -> setGravityEnable(true);
	physicsbody -> setRotationEnable(false);
	//physicsbody -> setVelocityLimit(250);
	this->setPhysicsBody(physicsbody);
	
	//���Ӿ������
	this->m_ActorSprite=Sprite::create();
	this->m_ActorSprite->setTexture(texture);
	this -> m_ActorSprite -> setTextureRect(rect);
	this->addChild(m_ActorSprite);


	m_AttackSprite = Sprite::create();
	PhysicsBody* AttackBox = PhysicsBody::createBox(Size(rect.getMaxX() * 0.8,rect.getMaxY()));
	AttackBox -> setGravityEnable(false);
	AttackBox -> setCategoryBitmask(64);
	AttackBox -> setContactTestBitmask(4);
	AttackBox -> setCollisionBitmask(0);
	m_AttackSprite -> setPhysicsBody(AttackBox);
	this->addChild(m_AttackSprite);

	//���ö�ʱ�� 0.01sִ��һ��
	this->schedule(schedule_selector(Actor::update1), 0.01f);
}

void Actor::Run() {
	if(isAble) {
		this -> physicsbody -> setVelocity(Vec2(position * VelocityX,physicsbody -> getVelocity().y));
		Status = run;
	}
}
void Actor::StopRunning() {
	if(isAble) {
		this -> physicsbody -> setVelocity(Vec2(0,physicsbody -> getVelocity().y));
		//position = 0;
		Status = stop;
	}
}

void Actor::Jump() {
	if(!isAble) return;
	if(onGround && abs(physicsbody -> getVelocity().y) < 5) {
		this -> physicsbody -> setVelocity(Vec2(physicsbody->getVelocity().x, 350));
	}
	onGround = false;
	Status = jump;
}

void Actor::Attack() {
	if(isAble)
		Status = attack;
}
void Actor::HitBack(float pos) {
	Status = hit;
	this -> physicsbody -> setVelocity(Vec2(100*(pos<0?-1:1), 100));
	onGround = false;
	isAble = false;
}
void Actor::update1(float dt) {
	//this -> physicsbody -> setVelocity(Vec2(position*VelocityX,physicsbody -> getVelocity().y));
	float vx = (float)physicsbody -> getVelocity().x;
	if(abs(vx) > 2) {
		if(position > 0)
			this -> m_ActorSprite -> setRotationY(0);
		else if(position < 0)
			this -> m_ActorSprite -> setRotationY(180);
	}
	RunAnimation();
	m_AttackSprite -> setPosition(position*(textureRect.getMaxX() - 10),0);
}
void Actor::SetAnimation(status str, myAnimation ani) {
	if(str == status::run)
		runAnimation = ani;
	else if(str == status::attack)
		attackAnimation = ani;
	else if(str == status::dead)
		deadAnimation = ani;
}
void Actor::RunAnimation() {
	if(currentStatus == attack) {
		if(!m_ActorSprite -> isFrameDisplayed(attackAnimation.animFrames.at(attackAnimation.animFrames.size()-1))) {
			if(m_ActorSprite -> isFrameDisplayed(attackAnimation.animFrames.at(attackAnimation.animFrames.size()-3))) 
				isAttackValid = true; 
			return;
		} else {
			isAttackValid = false;
		}
	}
	if(currentStatus == dead) {
		if(!m_ActorSprite -> isFrameDisplayed(deadAnimation.animFrames.at(deadAnimation.animFrames.size()-1)))
			return;
		else {
			if(CCRANDOM_0_1() < 0.7) 
				Drop();
			CC_SAFE_RETAIN(this);
			removeFromParent();
		}
	}
	switch(this -> Status) {
		case status::run :
			if(currentStatus != run) {
				this -> m_ActorSprite -> runAction(runAnimation.getAnimation());
				currentStatus = run;
			}
			break;
		case status::stop:
			this -> m_ActorSprite -> stopAllActions();
			this -> m_ActorSprite -> setVisible(true);  
			this -> m_ActorSprite -> setTexture(texture);
			this -> m_ActorSprite -> setTextureRect(textureRect);
			currentStatus = stop;
			break;
		case status::attack:
			this -> m_ActorSprite -> stopAllActions();
			if(currentStatus != attack) {
				isAttackValid = false;
				this -> m_ActorSprite -> runAction(attackAnimation.getAnimation());
			}
			Status = stop;
			currentStatus = attack;
			break;
		case status::jump:
			currentStatus = jump;
			break;
		case status::hit:
			if(onGround) {
				isAble = true;
				StopRunning();
				log("onGround!");
			} else {
				if(currentStatus != hit) {
					CCBlink* blink= CCBlink::create(1,3);
					this -> m_ActorSprite -> runAction(blink);
				}
				currentStatus = hit;
			}
			break;
		case status::dead:
			isAble = false;
			this -> m_ActorSprite -> stopAllActions();
			if(currentStatus != dead) {
				this -> m_ActorSprite -> runAction(deadAnimation.getAnimation());
			}
			currentStatus = dead;
			break;
	}
}

void Actor::AddActorValue(Vec3 v3) {
	life = (life + v3.x > 100)?100:(life + v3.x);
	power += v3.y;
	defence += v3.z;
}

void Actor::Drop() {
	auto peach = Prop::CreatePeach();
	peach -> setPosition(getPositionX(), getPositionY());
	peach -> setTag(5);
	peach -> setScale(0.6);
	getParent() -> addChild(peach,5);
}

Rect Actor::collisionBoundingBox() {
	Rect collisionBox = Tools::RectInset(m_ActorSprite->getBoundingBox(), 3, 0);
	Rect returnBoundingBox = Tools::RectOffset(collisionBox, physicsbody -> getVelocity()); //������������ײ��,����Χ��x,y�᷽�����ƶ�diff.x, diff.y����λ
	return returnBoundingBox;
}
