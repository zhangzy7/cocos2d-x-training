#ifndef __SETTING_SCENE_H__
#define __SETTING_SCENE_H__

#include "cocos2d.h"
#include "extensions/cocos-ext.h"
#include "ui/cocosgui.h"

USING_NS_CC_EXT;


class SettingScene : public cocos2d::Layer
{
public:
	// there's no 'id' in cpp, so we recommend returning the class instance pointer
	static cocos2d::Scene* createScene();

	// Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
	virtual bool init();

	// a selector callback
	void menuCloseCallback(cocos2d::Ref* pSender);

	void toHelloWorldScene(cocos2d::Ref* pSender);

	// implement the "static create()" method manually
	CREATE_FUNC(SettingScene);

private:
	EditBox* upmove_box;
	EditBox* downmove_box;
	EditBox* leftmove_box;
	EditBox* rightmove_box;
	EditBox* attack_box;
	EditBox* jump_box;
	EditBox* pick_box;
	EditBox* shop_box;
	EditBox* prop1_box;
	EditBox* prop2_box;
	EditBox* skill1_box;
	EditBox* skill2_box;
	EditBox* skill3_box;
};

#endif