#include "player.h"
Player::Player() {
	InitActorSprite("img/animation/Players/stand_right1.png",Rect(0,0,43,71));

	myAnimation runAni = myAnimation::createWithPlist("walk_right", 4, true);
	runAni.setSpeed(0.2f);
	SetAnimation(status::run, runAni);

	myAnimation attackani = myAnimation::createWithPlist("swing_right", 4, false);
	attackani.animFrames.pushBack( CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("walk_right0.png"));
	attackani.setSpeed(0.2f);
	SetAnimation(status::attack, attackani);

	myAnimation deadAni = myAnimation::createWithPlist("stand_right", 5, true);
	deadAni.setSpeed(0.2f);
	SetAnimation(status::dead, deadAni);

	physicsbody -> setCategoryBitmask(1);
	physicsbody -> setContactTestBitmask(14);
	physicsbody -> setCollisionBitmask(18);

	life = 100;
	power = 50;
	defence = 0;

	m_AttackSprite -> setTag(ATTACK_TAG);
}
void Player::attack() {
	if(isAble)
		Status = status::attack;
}