#include "SettingScene.h"
#include "HelloWorldScene.h"
#include "GameConstants.h"
#include "HelpLayer.h"
#include "IconvString.h"

#define jj 40
USING_NS_CC;

Scene* SettingScene::createScene()
{
	auto scene = Scene::create();
	auto layer = SettingScene::create();
	scene->addChild(layer);
	return scene;
}

bool SettingScene::init()
{
	if (!Layer::init())
	{
		return false;
	}

	Size visibleSize = Director::getInstance()->getVisibleSize();
	Vec2 origin = Director::getInstance()->getVisibleOrigin();

	auto closeItem = MenuItemImage::create(
		"CloseNormal.png",
		"CloseSelected.png",
		CC_CALLBACK_1(SettingScene::toHelloWorldScene, this));

	closeItem->setPosition(Vec2(origin.x + visibleSize.width - closeItem->getContentSize().width / 2,
		origin.y + closeItem->getContentSize().height / 2));
	auto menu = Menu::create(closeItem, NULL);
	menu->setPosition(Vec2::ZERO);
	this->addChild(menu, 1);

	// Layer0: backgroud
	// Layer1: closeItem  header edtibox

	// ���ӱ���
	auto *background = Sprite::create("Image/SettingScene/Background.jpg");
	background->setScale(1.2f);
	background->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
	this->addChild(background, 0);

	// ���ӱ���
	char *inBuf = "����";
	size_t inLen = strlen(inBuf);
	size_t outLen = inLen << 1;
	char *outBuf = (char*)malloc(outLen);
	gbk2utf8(inBuf, inLen, outBuf, outLen);
	LabelTTF* header = LabelTTF::create(outBuf, "Arial", 72);
	header->setColor(Color3B::BLACK);
	header->setPosition(Point(visibleSize.width / 2, visibleSize.height - 48));
	this->addChild(header, 1);
	free(outBuf);

	float hg = visibleSize.height - 132;
	float wg = visibleSize.width / 2 - 72;

	// ����editbox
	inBuf = "��";
	inLen = strlen(inBuf);
	outLen = inLen << 1;
	outBuf = (char*)malloc(outLen);
	gbk2utf8(inBuf, inLen, outBuf, outLen);
	LabelTTF* upmove = LabelTTF::create(outBuf, "Arial", 36);
	upmove->setColor(Color3B::BLACK);
	upmove->setPosition(Point(wg - upmove->getContentSize().width, hg));
	this->addChild(upmove, 1);
	free(outBuf);
	
	auto upmove_bg = Sprite::create("Image/SettingScene/Editbox.png");
	upmove_bg->setPosition(Point(visibleSize.width / 2, hg));
	this->addChild(upmove_bg, 1);
	upmove_box = EditBox::create(Size(144.0f, 36.0f), Scale9Sprite::create());
	upmove_box->setPosition(Point(visibleSize.width / 2, hg));
	upmove_box->setInputMode(EditBox::InputMode::SINGLE_LINE);
	upmove_box->setFontColor(Color3B::WHITE);
	upmove_box->setText("W");
	this->addChild(upmove_box, 2);

	hg = hg - jj;
	inBuf = "��";
	inLen = strlen(inBuf);
	outLen = inLen << 1;
	outBuf = (char*)malloc(outLen);
	gbk2utf8(inBuf, inLen, outBuf, outLen);
	LabelTTF* downmove = LabelTTF::create(outBuf, "Arial", 36);
	downmove->setColor(Color3B::BLACK);
	downmove->setPosition(Point(wg - upmove->getContentSize().width, hg));
	this->addChild(downmove, 1);
	free(outBuf);

	auto downmove_bg = Sprite::create("Image/SettingScene/Editbox.png");
	downmove_bg->setPosition(Point(visibleSize.width / 2, hg));
	this->addChild(downmove_bg, 1);
	downmove_box = EditBox::create(Size(144.0f, 36.0f), Scale9Sprite::create());
	downmove_box->setPosition(Point(visibleSize.width / 2, hg));
	downmove_box->setInputMode(EditBox::InputMode::SINGLE_LINE);
	downmove_box->setFontColor(Color3B::WHITE);
	downmove_box->setText("S");
	this->addChild(downmove_box, 2);

	hg = hg - jj;
	inBuf = "��";
	inLen = strlen(inBuf);
	outLen = inLen << 1;
	outBuf = (char*)malloc(outLen);
	gbk2utf8(inBuf, inLen, outBuf, outLen);
	LabelTTF* leftmove = LabelTTF::create(outBuf, "Arial", 36);
	leftmove->setColor(Color3B::BLACK);
	leftmove->setPosition(Point(wg - upmove->getContentSize().width, hg));
	this->addChild(leftmove, 1);
	free(outBuf);

	auto leftmove_bg = Sprite::create("Image/SettingScene/Editbox.png");
	leftmove_bg->setPosition(Point(visibleSize.width / 2, hg));
	this->addChild(leftmove_bg, 1);
	leftmove_box = EditBox::create(Size(144.0f, 36.0f), Scale9Sprite::create());
	leftmove_box->setPosition(Point(visibleSize.width / 2, hg));
	leftmove_box->setInputMode(EditBox::InputMode::SINGLE_LINE);
	leftmove_box->setFontColor(Color3B::WHITE);
	leftmove_box->setText("A");
	this->addChild(leftmove_box, 2);

	hg = hg - jj;
	inBuf = "��";
	inLen = strlen(inBuf);
	outLen = inLen << 1;
	outBuf = (char*)malloc(outLen);
	gbk2utf8(inBuf, inLen, outBuf, outLen);
	LabelTTF* rightmove = LabelTTF::create(outBuf, "Arial", 36);
	rightmove->setColor(Color3B::BLACK);
	rightmove->setPosition(Point(wg - upmove->getContentSize().width, hg));
	this->addChild(rightmove, 1);
	free(outBuf);

	auto rightmove_bg = Sprite::create("Image/SettingScene/Editbox.png");
	rightmove_bg->setPosition(Point(visibleSize.width / 2, hg));
	this->addChild(rightmove_bg, 1);
	rightmove_box = EditBox::create(Size(144.0f, 36.0f), Scale9Sprite::create());
	rightmove_box->setPosition(Point(visibleSize.width / 2, hg));
	rightmove_box->setInputMode(EditBox::InputMode::SINGLE_LINE);
	rightmove_box->setFontColor(Color3B::WHITE);
	rightmove_box->setText("D");
	this->addChild(rightmove_box, 2);

	hg = hg - jj;
	inBuf = "����";
	inLen = strlen(inBuf);
	outLen = inLen << 1;
	outBuf = (char*)malloc(outLen);
	gbk2utf8(inBuf, inLen, outBuf, outLen);
	LabelTTF* attackmove = LabelTTF::create(outBuf, "Arial", 36);
	attackmove->setColor(Color3B::BLACK);
	attackmove->setPosition(Point(wg - upmove->getContentSize().width, hg));
	this->addChild(attackmove, 1);
	free(outBuf);

	auto attackmove_bg = Sprite::create("Image/SettingScene/Editbox.png");
	attackmove_bg->setPosition(Point(visibleSize.width / 2, hg));
	this->addChild(attackmove_bg, 1);
	attack_box = EditBox::create(Size(144.0f, 36.0f), Scale9Sprite::create());
	attack_box->setPosition(Point(visibleSize.width / 2, hg));
	attack_box->setInputMode(EditBox::InputMode::SINGLE_LINE);
	attack_box->setFontColor(Color3B::WHITE);
	attack_box->setText("J");
	this->addChild(attack_box, 2);

	hg = hg - jj;
	inBuf = "��Ծ";
	inLen = strlen(inBuf);
	outLen = inLen << 1;
	outBuf = (char*)malloc(outLen);
	gbk2utf8(inBuf, inLen, outBuf, outLen);
	LabelTTF* jumpmove = LabelTTF::create(outBuf, "Arial", 36);
	jumpmove->setColor(Color3B::BLACK);
	jumpmove->setPosition(Point(wg - upmove->getContentSize().width, hg));
	this->addChild(jumpmove, 1);
	free(outBuf);

	auto jumpmove_bg = Sprite::create("Image/SettingScene/Editbox.png");
	jumpmove_bg->setPosition(Point(visibleSize.width / 2, hg));
	this->addChild(jumpmove_bg, 1);
	jump_box = EditBox::create(Size(144.0f, 36.0f), Scale9Sprite::create());
	jump_box->setPosition(Point(visibleSize.width / 2, hg));
	jump_box->setInputMode(EditBox::InputMode::SINGLE_LINE);
	jump_box->setFontColor(Color3B::WHITE);
	jump_box->setText("K");
	this->addChild(jump_box, 2);

	hg = hg - jj;
	inBuf = "��";
	inLen = strlen(inBuf);
	outLen = inLen << 1;
	outBuf = (char*)malloc(outLen);
	gbk2utf8(inBuf, inLen, outBuf, outLen);
	LabelTTF* pickmove = LabelTTF::create(outBuf, "Arial", 36);
	pickmove->setColor(Color3B::BLACK);
	pickmove->setPosition(Point(wg - upmove->getContentSize().width, hg));
	this->addChild(pickmove, 1);
	free(outBuf);

	auto pickmove_bg = Sprite::create("Image/SettingScene/Editbox.png");
	pickmove_bg->setPosition(Point(visibleSize.width / 2, hg));
	this->addChild(pickmove_bg, 1);
	pick_box = EditBox::create(Size(144.0f, 36.0f), Scale9Sprite::create());
	pick_box->setPosition(Point(visibleSize.width / 2, hg));
	pick_box->setInputMode(EditBox::InputMode::SINGLE_LINE);
	pick_box->setFontColor(Color3B::WHITE);
	pick_box->setText("Q");
	this->addChild(pick_box, 2);

	hg = hg - jj;
	inBuf = "�̵�";
	inLen = strlen(inBuf);
	outLen = inLen << 1;
	outBuf = (char*)malloc(outLen);
	gbk2utf8(inBuf, inLen, outBuf, outLen);
	LabelTTF* shopmove = LabelTTF::create(outBuf, "Arial", 36);
	shopmove->setColor(Color3B::BLACK);
	shopmove->setPosition(Point(wg - upmove->getContentSize().width, hg));
	this->addChild(shopmove, 1);
	free(outBuf);

	auto shopmove_bg = Sprite::create("Image/SettingScene/Editbox.png");
	shopmove_bg->setPosition(Point(visibleSize.width / 2, hg));
	this->addChild(shopmove_bg, 1);
	shop_box = EditBox::create(Size(144.0f, 36.0f), Scale9Sprite::create());
	shop_box->setPosition(Point(visibleSize.width / 2, hg));
	shop_box->setInputMode(EditBox::InputMode::SINGLE_LINE);
	shop_box->setFontColor(Color3B::WHITE);
	shop_box->setText("P");
	this->addChild(shop_box, 2);

	hg = hg - jj;
	inBuf = "����1";
	inLen = strlen(inBuf);
	outLen = inLen << 1;
	outBuf = (char*)malloc(outLen);
	gbk2utf8(inBuf, inLen, outBuf, outLen);
	LabelTTF* prop1 = LabelTTF::create(outBuf, "Arial", 36);
	prop1->setColor(Color3B::BLACK);
	prop1->setPosition(Point(wg - upmove->getContentSize().width - 10, hg));
	this->addChild(prop1, 1);
	free(outBuf);

	auto prop1_bg = Sprite::create("Image/SettingScene/Editbox.png");
	prop1_bg->setPosition(Point(visibleSize.width / 2, hg));
	this->addChild(prop1_bg, 1);
	prop1_box = EditBox::create(Size(144.0f, 36.0f), Scale9Sprite::create());
	prop1_box->setPosition(Point(visibleSize.width / 2, hg));
	prop1_box->setInputMode(EditBox::InputMode::SINGLE_LINE);
	prop1_box->setFontColor(Color3B::WHITE);
	prop1_box->setText("N");
	this->addChild(prop1_box, 2);

	hg = hg - jj;
	inBuf = "����2";
	inLen = strlen(inBuf);
	outLen = inLen << 1;
	outBuf = (char*)malloc(outLen);
	gbk2utf8(inBuf, inLen, outBuf, outLen);
	LabelTTF* prop2 = LabelTTF::create(outBuf, "Arial", 36);
	prop2->setColor(Color3B::BLACK);
	prop2->setPosition(Point(wg - upmove->getContentSize().width - 10, hg));
	this->addChild(prop2, 1);
	free(outBuf);

	auto prop2_bg = Sprite::create("Image/SettingScene/Editbox.png");
	prop2_bg->setPosition(Point(visibleSize.width / 2, hg));
	this->addChild(prop2_bg, 1);
	prop2_box = EditBox::create(Size(144.0f, 36.0f), Scale9Sprite::create());
	prop2_box->setPosition(Point(visibleSize.width / 2, hg));
	prop2_box->setInputMode(EditBox::InputMode::SINGLE_LINE);
	prop2_box->setFontColor(Color3B::WHITE);
	prop2_box->setText("M");
	this->addChild(prop2_box, 2);

	hg = hg - jj;
	inBuf = "����1";
	inLen = strlen(inBuf);
	outLen = inLen << 1;
	outBuf = (char*)malloc(outLen);
	gbk2utf8(inBuf, inLen, outBuf, outLen);
	LabelTTF* skill1 = LabelTTF::create(outBuf, "Arial", 36);
	skill1->setColor(Color3B::BLACK);
	skill1->setPosition(Point(wg - upmove->getContentSize().width - 10, hg));
	this->addChild(skill1, 1);
	free(outBuf);

	auto skill1_bg = Sprite::create("Image/SettingScene/Editbox.png");
	skill1_bg->setPosition(Point(visibleSize.width / 2, hg));
	this->addChild(skill1_bg, 1);
	skill1_box = EditBox::create(Size(144.0f, 36.0f), Scale9Sprite::create());
	skill1_box->setPosition(Point(visibleSize.width / 2, hg));
	skill1_box->setInputMode(EditBox::InputMode::SINGLE_LINE);
	skill1_box->setFontColor(Color3B::WHITE);
	skill1_box->setText("U");
	this->addChild(skill1_box, 2);

	hg = hg - jj;
	inBuf = "����2";
	inLen = strlen(inBuf);
	outLen = inLen << 1;
	outBuf = (char*)malloc(outLen);
	gbk2utf8(inBuf, inLen, outBuf, outLen);
	LabelTTF* skill2 = LabelTTF::create(outBuf, "Arial", 36);
	skill2->setColor(Color3B::BLACK);
	skill2->setPosition(Point(wg - upmove->getContentSize().width - 10, hg));
	this->addChild(skill2, 1);
	free(outBuf);

	auto skill2_bg = Sprite::create("Image/SettingScene/Editbox.png");
	skill2_bg->setPosition(Point(visibleSize.width / 2, hg));
	this->addChild(skill2_bg, 1);
	skill2_box = EditBox::create(Size(144.0f, 36.0f), Scale9Sprite::create());
	skill2_box->setPosition(Point(visibleSize.width / 2, hg));
	skill2_box->setInputMode(EditBox::InputMode::SINGLE_LINE);
	skill2_box->setFontColor(Color3B::WHITE);
	skill2_box->setText("I");
	this->addChild(skill2_box, 2);

	hg = hg - jj;
	inBuf = "����3";
	inLen = strlen(inBuf);
	outLen = inLen << 1;
	outBuf = (char*)malloc(outLen);
	gbk2utf8(inBuf, inLen, outBuf, outLen);
	LabelTTF* skill3 = LabelTTF::create(outBuf, "Arial", 36);
	skill3->setColor(Color3B::BLACK);
	skill3->setPosition(Point(wg - upmove->getContentSize().width - 10, hg));
	this->addChild(skill3, 1);
	free(outBuf);

	auto skill3_bg = Sprite::create("Image/SettingScene/Editbox.png");
	skill3_bg->setPosition(Point(visibleSize.width / 2, hg));
	this->addChild(skill3_bg, 1);
	skill3_box = EditBox::create(Size(144.0f, 36.0f), Scale9Sprite::create());
	skill3_box->setPosition(Point(visibleSize.width / 2, hg));
	skill3_box->setInputMode(EditBox::InputMode::SINGLE_LINE);
	skill3_box->setFontColor(Color3B::WHITE);
	skill3_box->setText("O");
	this->addChild(skill3_box, 2);

	return true;
}

void SettingScene::toHelloWorldScene(Ref* pSender){
	auto move_text = upmove_box->getText();
	if (CovertToKeyCode(move_text) != EventKeyboard::KeyCode::KEY_SPACE)
		MOVE_UP = CovertToKeyCode(move_text);

	move_text = downmove_box->getText();
	if (CovertToKeyCode(move_text) != EventKeyboard::KeyCode::KEY_SPACE)
		MOVE_DOWN = CovertToKeyCode(move_text);

	move_text = leftmove_box->getText();
	if (CovertToKeyCode(move_text) != EventKeyboard::KeyCode::KEY_SPACE)
		MOVE_LEFT = CovertToKeyCode(move_text);

	move_text = rightmove_box->getText();
	if (CovertToKeyCode(move_text) != EventKeyboard::KeyCode::KEY_SPACE)
		MOVE_RIGHT = CovertToKeyCode(move_text);

	move_text = attack_box->getText();
	if (CovertToKeyCode(move_text) != EventKeyboard::KeyCode::KEY_SPACE)
		ATTACK = CovertToKeyCode(move_text);

	move_text = jump_box->getText();
	if (CovertToKeyCode(move_text) != EventKeyboard::KeyCode::KEY_SPACE)
		JUMP = CovertToKeyCode(move_text);

	move_text = pick_box->getText();
	if (CovertToKeyCode(move_text) != EventKeyboard::KeyCode::KEY_SPACE)
		PICK = CovertToKeyCode(move_text);

	move_text = shop_box->getText();
	if (CovertToKeyCode(move_text) != EventKeyboard::KeyCode::KEY_SPACE)
		SHOP = CovertToKeyCode(move_text);

	move_text = prop1_box->getText();
	if (CovertToKeyCode(move_text) != EventKeyboard::KeyCode::KEY_SPACE)
		PROP1 = CovertToKeyCode(move_text);

	move_text = prop2_box->getText();
	if (CovertToKeyCode(move_text) != EventKeyboard::KeyCode::KEY_SPACE)
		PROP2 = CovertToKeyCode(move_text);

	move_text = skill1_box->getText();
	if (CovertToKeyCode(move_text) != EventKeyboard::KeyCode::KEY_SPACE)
		SKILL1 = CovertToKeyCode(move_text);

	move_text = skill2_box->getText();
	if (CovertToKeyCode(move_text) != EventKeyboard::KeyCode::KEY_SPACE)
		SKILL2 = CovertToKeyCode(move_text);

	move_text = skill3_box->getText();
	if (CovertToKeyCode(move_text) != EventKeyboard::KeyCode::KEY_SPACE)
		SKILL3 = CovertToKeyCode(move_text);

	Director::getInstance()->replaceScene(TransitionShrinkGrow::create(0.2f, HelloWorld::createScene()));
}

void SettingScene::menuCloseCallback(Ref* pSender)
{
	Director::getInstance()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
	exit(0);
#endif
}