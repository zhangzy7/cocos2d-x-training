#ifndef __MENUSCENE_SCENE_H__
#define __MENUSCENE_SCENE_H__

#include "cocos2d.h"
#include "SimpleAudioEngine.h"
#include "GameScene.h"

using namespace CocosDenshion;

#define MENU_MUSIC_FILE  "bgm/0.mp3"
#define MENU_BG_FILE     "img/bg/bg02.png"
#define MENU_BUTTON_FILE  "img/button/button01.png"
#define MENU_BUTTON_FILE2 "img/button/button02.png"

class MenuScene : public cocos2d::Layer
{
public:
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene();

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
    
    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);

	void turnToSelectScene(cocos2d::Ref* pSender);
	void turnToGameScene(cocos2d::Ref* pSender);
    // implement the "static create()" method manually
    CREATE_FUNC(MenuScene);
};

#endif // __HELLOWORLD_SCENE_H__
