#ifndef __LOAD_SCENE__
#define __LOAD_SCENE__

#include "cocos2d.h"
#include "LevelSelectContent.h"

USING_NS_CC;

const int LevelSelectTopCoinTag = 1;

class LoadScene :public Layer{

public:
	LoadScene();
	~LoadScene();
	virtual bool init();
	CREATE_FUNC(LoadScene);
	void menuCloseCallback(cocos2d::Ref* pSender);
	void toHelloWorldScene(cocos2d::Ref* pSender);
	static cocos2d::Scene* createScene();
private:
	LevelSelectContent* levelSelectContent;
	int _currentPage;
	int _maxPage;
	Menu* _leftMenu;
	Menu* _rightMenu;

	void initNavigation();
	void initAllLevels();
	void nextPageBack(Ref* sender);
	void prePageBack(Ref* sender);
};

#endif