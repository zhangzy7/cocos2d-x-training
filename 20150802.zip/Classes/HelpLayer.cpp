#include "HelpLayer.h"
#include <fstream>
#include <iostream>
#include <string>
using namespace std;

Scene* HelpLayer::scene() {
	Scene* ans = NULL;
	do {
		ans = Scene::create();
		HelpLayer* layer = HelpLayer::create();
		ans->addChild(layer);
	} while (0);
	return ans;
}

bool HelpLayer::init() {
	bool bRet = false;
	do {
		CC_BREAK_IF(!Layer::init());
		Size winSize = Director::sharedDirector()->getWinSize();
		Sprite* background = Sprite::create("Image/HelpLayer/Background.jpg");
		m_bgSprite = background;
		background->setScale(0.75f);
		background->setPosition(ccp(winSize.width / 2, winSize.height / 2));
		this->addChild(background);

		Size contentSize = background->getContentSize();
		m_size = contentSize;

		MenuItemImage* backItem = MenuItemImage::create("Image/HelpLayer/back.png",
			"Image/HelpLayer/Back_selected.png", "", this, menu_selector(HelpLayer::BackButton));
		Menu* menu = Menu::create(backItem, NULL);
		menu->alignItemsHorizontallyWithPadding(5);
		menu->setPosition(ccp(contentSize.width / 2, 68));

		background->addChild(menu);
		this->setTitle();
		this->setContent();

		bRet = true;
	} while (0);
	return bRet;
}

bool HelpLayer::TouchBegan(Touch* touch, Event* event) {
	return true;
}

void HelpLayer::BackButton(Object* object) {
	this->removeFromParentAndCleanup(true);
}

void HelpLayer::setTitle() {
	auto title = Label::createWithTTF("About the game", "fonts/Marker Felt.ttf", 36);
	title->setPosition(ccp(m_size.width / 2, m_size.height - title->getContentSize().height / 2));
	m_bgSprite->addChild(title);
}

void HelpLayer::setContent() {
	std::ifstream fin("File/About the game.txt");
	if (!fin.is_open()) return;
	float Height = m_size.height / 2;
	char buff[200];
	while (!fin.eof()) {
		fin.getline(buff, 100);
		auto content = Label::createWithTTF(buff, "fonts/Arial.ttf", 24);
		content->setPosition(ccp(m_size.width / 2, Height));
		content->setDimensions(this->m_size.width - 60, this->m_size.height - 100);
		content->setHorizontalAlignment(kCCTextAlignmentLeft);
		Height -= 24;
		m_bgSprite->addChild(content);
	}
}