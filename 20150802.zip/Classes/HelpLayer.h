#ifndef __Help_Layer_H__
#define __Help_Layer_H__
#include "cocos2d.h"

USING_NS_CC;

class HelpLayer : public  Layer
{
public:
	static Scene* scene();
	bool init();
	CREATE_FUNC(HelpLayer);
private:
	//void registerWithTouchDispatcher();
	bool TouchBegan(Touch * touch, Event * pevent);
	void BackButton(Object * object);
	void setTitle();
	void setContent();
	Size m_size;
	Sprite * m_bgSprite;
};

#endif
