#ifndef __GUILAYER_H__
#define __GUILAYER_H__
#include "cocos2d.h"
#include "cocos-ext.h"
USING_NS_CC; 
USING_NS_CC_EXT;

#define BLOOD_BG "img/button/1.png"
#define BLOOD_PROCESS "img/button/2.png"
#define BLOOD_SLIDERTHUMB "img/button/3.png"
class GuiLayer:public Layer {
	public:
		GuiLayer();
		~GuiLayer();
		virtual bool  init();
		//void update(float dt);
		CREATE_FUNC(GuiLayer);
};
#endif