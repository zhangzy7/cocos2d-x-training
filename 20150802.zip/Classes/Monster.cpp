#include "Monster.h"
Monster::Monster() {
	InitActorSprite("img/animation/HeiShiTouRen/stand_right0.png",Rect(0,0,179,155));

	myAnimation runAni = myAnimation::createWithPlist("move_right", 3, true);
	runAni.setSpeed(0.3f);
	SetAnimation(status::run, runAni);

	myAnimation deadani = myAnimation::createWithPlist("die_right", 7, false);
	deadani.setSpeed(0.3f);
	SetAnimation(status::dead, deadani);

	myAnimation attackani = myAnimation::createWithPlist("skill_right", 8, false);
	deadani.setSpeed(0.2f);
	SetAnimation(status::attack, attackani);

	setScale(0.6);
	physicsbody -> setCategoryBitmask(4);
	physicsbody -> setContactTestBitmask(99);
	physicsbody -> setCollisionBitmask(2);

	isInrange = false;
	isActive = false;
	VelocityX = 40;
	life = 100;
	power = 20;
	defence = 0;
	position = 1;
	Run();
	this->schedule(schedule_selector(Monster::AIControll), 0.8f);
	scheduleUpdate();
}
void Monster::AIControll(float dt) {
	if(!isActive) {
		if(abs(player->getPosition().x - getPosition().x) < 250 && 
				abs(player->getPosition().y - getPosition().y) < 50 &&
				  (player->getPosition().x - getPosition().x) * position > 0) {
			isActive = true;
			turnOnActive();
			Attack();
		}
		else {
			if(CCRANDOM_0_1() < 0.3) position *= -1;
			Run();
		}
	}
	else {
		position = (player -> getPosition().x < getPosition().x)?-1:1;
		if(abs(player->getPosition().x - getPosition().x) > 300  || 
				abs(player->getPosition().y - getPosition().y) > 50) {
			isActive = false;
			turnOffActive();
		}
		Run();
	}
	
}
void Monster::turnOnActive() {
	m_ActorSprite ->setColor(ccc3(200, 255, 255));
	AddActorValue(Vec3(0, 10, 10));
	VelocityX += 40;
}
void Monster::turnOffActive() {
	m_ActorSprite ->setColor(Color3B::WHITE);
	AddActorValue(Vec3(0, -10, -10));
	VelocityX -= 40;
}
void Monster::update(float dt) {
	if(isInrange && player -> currentStatus == status::attack && player -> isAttackValid && currentStatus != status::hit && Status != status::hit) {
		life -= player->power - defence;
		log("life:%d", life);
		if(life <= 0) {
			StopRunning();
			this->removeFromPhysicsWorld();
			Status = status::dead;
		} else {
			HitBack(getPosition().x - player->getPositionX());
		}
	}
}