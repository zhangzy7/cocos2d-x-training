#ifndef __GAMELAYER_H__
#define __GAMELAYER_H__
#include "cocos2d.h"
#include "Player.h"
#include "Monster.h"
#include "Prop.h"
#include "GamePauseScene.h"
#include "GameConstants.h"
#define PLAYER_TAG  0
#define WALL_TAG    1
#define HAZARD_TAG  2
#define MONSTER_TAG 3
#define EDGE_TAG    4
#define PROP_TAG    5
using namespace cocos2d;
class GameLayer:public Layer {
	public:
		Player* player;
		GameLayer();
		~GameLayer();
		virtual bool  init();
		void CreateMonster();
		void CreateBox();
		void CreateBoxForTile(Sprite*, int, int, Vec3);
		void onKeyPressed(EventKeyboard::KeyCode, Event*);
		void onKeyReleased(EventKeyboard::KeyCode, Event*);
		bool onContactBegin(const PhysicsContact&);
		void onContactSeperate(const PhysicsContact&);
		void setViewpointCenter(Point, float);
		void update(float dt);
		CREATE_FUNC(GameLayer);
	private:
		TMXTiledMap* _map;
		TMXLayer* _edge;
		TMXLayer* _wall;
		TMXLayer* _hazard;
		float locX;
};
#endif