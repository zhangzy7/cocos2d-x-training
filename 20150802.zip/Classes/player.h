#ifndef __PLAYER_H__
#define __PLAYER_H__
#include "Actor.h"
using namespace cocos2d;
#define ATTACK_TAG 12
USING_NS_CC;
class Player:public Actor {
	public:
		Player();
		void attack();
		CREATE_FUNC(Player);
};
#endif