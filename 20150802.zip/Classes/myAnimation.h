#include "cocos2d.h"
USING_NS_CC;
class myAnimation {
	public:
		Vector<SpriteFrame *> animFrames;
		float time;
		bool isrepeat;
		myAnimation() {};
		static myAnimation createWithTexture(Texture2D*, Vec2, int frameorder[], int framenum, bool isrepeat = true);
		static myAnimation createWithPlist(char*, int, bool); 
		myAnimation* setSpeed(float time);
		Action* getAnimation();
};