#include "ToBeCScene.h"
#include "HelloWorldScene.h"

USING_NS_CC;

Scene* ToBeCScene::createScene()
{
	auto scene = Scene::create();
	auto layer = ToBeCScene::create();
	scene->addChild(layer);
	return scene;
}

bool ToBeCScene::init()
{
	if (!Layer::init())
	{
		return false;
	}

	Size visibleSize = Director::getInstance()->getVisibleSize();
	Vec2 origin = Director::getInstance()->getVisibleOrigin();

	auto closeItem = MenuItemImage::create(
		"CloseNormal.png",
		"CloseSelected.png",
		CC_CALLBACK_1(ToBeCScene::toHelloWorldScene, this));

	closeItem->setPosition(Vec2(origin.x + visibleSize.width - closeItem->getContentSize().width / 2,
		origin.y + closeItem->getContentSize().height / 2));
	auto menu = Menu::create(closeItem, NULL);
	menu->setPosition(Vec2::ZERO);
	this->addChild(menu, 1);

	auto *background = Sprite::create("Image/ToBeCScene/ToBeC.png");
	background->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
	this->addChild(background, 0);

	return true;
}

void ToBeCScene::menuCloseCallback(Ref* pSender)
{
	Director::getInstance()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
	exit(0);
#endif
}

void ToBeCScene::toHelloWorldScene(Ref* pSender){
	Director::getInstance()->replaceScene(TransitionShrinkGrow::create(0.2f, HelloWorld::createScene()));
}
