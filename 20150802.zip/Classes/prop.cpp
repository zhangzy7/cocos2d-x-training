#include "prop.h"
Prop::Prop() {}
Prop::~Prop() {}
void Prop::InitPropSprite(char* name, Rect rect) {
	//���þ������
	auto texture = TextureCache::sharedTextureCache()->addImage(name);
	this->m_ActorSprite=Sprite::create();
	this->m_ActorSprite->setTexture(texture);
	this -> m_ActorSprite -> setTextureRect(rect);
	this->addChild(m_ActorSprite);

	//������������
	physicsbody = PhysicsBody::createBox(Size(rect.getMaxX(), rect.getMaxY()),
		PhysicsMaterial(0.1f, 0.0f, 0.0f));  //1��density���ܶȣ�2��restiution�����ԣ�3��friction��Ħ������
	physicsbody -> setGravityEnable(true);
	physicsbody -> setCategoryBitmask(8);
	physicsbody -> setContactTestBitmask(1);
	physicsbody -> setCollisionBitmask(2);
	//physicsbody -> setVelocityLimit(250);
	this->setPhysicsBody(physicsbody);
}

Prop* Prop::CreatePeach() {
	auto prop = Prop::create();
	prop -> InitPropSprite("img/animation/peach1.png",Rect(0,0,33,34));
	prop -> value = Vec3(25,0,0);
	return prop;
}

void Prop::removeProp() {
	CC_SAFE_RETAIN(this);
	removeFromParent();
}