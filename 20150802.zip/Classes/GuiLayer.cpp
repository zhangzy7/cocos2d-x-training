#include "GuiLayer.h" 
GuiLayer::GuiLayer() {}
GuiLayer::~GuiLayer() {}
bool GuiLayer::init() {
    Size visibleSize = Director::getInstance()->getVisibleSize();
	auto slide_control = ControlSlider::create(BLOOD_BG,BLOOD_PROCESS,BLOOD_SLIDERTHUMB);
	slide_control->setMinimumValue(0.0f);//������Сֵ
	slide_control->setMaximumValue(100.0f);//�������ֵ
	slide_control->setValue(70.0f);//���ó�ʼֵ
	slide_control->setTag(20);
	slide_control->setScale(1.5);
	slide_control->setPosition(Point(150,visibleSize.height-50));
	//slide_control->addTargetWithActionForControlEvents(this,cccontrol_selector(HelloWorld::slideCallback),Control::EventType::VALUE_CHANGED);//�����϶��ص�	
	this->addChild(slide_control,2);
	return true;
}