#include "HelloWorldScene.h"
#include "LoadScene.h"
#include "SettingScene.h"
#include "HelpLayer.h"
#include "MenuScene.h"
#include "GameConstants.h"
#include "extensions/cocos-ext.h"
#include "ui/cocosgui.h"
#include "IconvString.h"

USING_NS_CC_EXT;
USING_NS_CC;

Scene* HelloWorld::createScene()
{
    auto scene = Scene::create();
    auto layer = HelloWorld::create();
    scene->addChild(layer);
    return scene;
}

bool HelloWorld::init()
{
    if ( !Layer::init() )
    {
        return false;
    }
    
    Size visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    auto closeItem = MenuItemImage::create(
                                           "CloseNormal.png",
                                           "CloseSelected.png",
                                           CC_CALLBACK_1(HelloWorld::menuCloseCallback, this));
    
	closeItem->setPosition(Vec2(origin.x + visibleSize.width - closeItem->getContentSize().width/2 ,
                                origin.y + closeItem->getContentSize().height/2));
    auto menu = Menu::create(closeItem, NULL);
    menu->setPosition(Vec2::ZERO);
    this->addChild(menu, 1);

	// Layer0: backgroud
	// Layer1: GameMenu  closeItem
	// Layer4: HelpLayer

    // ���ӱ���
	auto *background = Sprite::create("Image/HelloWorldScene/Background.jpg");
	background->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
	this->addChild(background, 0);
	 
	// ����GameMenu
	auto NewGame = MenuItemImage::create(
		"Image/HelloWorldScene/NewGame_normal.png",
		"Image/HelloWorldScene/NewGame_selected.png",
		CC_CALLBACK_1(HelloWorld::toRoundFirst, this));
	auto Load = MenuItemImage::create(
		"Image/HelloWorldScene/Load_normal.png",
		"Image/HelloWorldScene/Load_selected.png",
		CC_CALLBACK_1(HelloWorld::toLoadScene, this));
	auto Help = MenuItemImage::create(
		"Image/HelloWorldScene/Help_normal.png",
		"Image/HelloWorldScene/Help_selected.png",
		CC_CALLBACK_1(HelloWorld::PopHelpLayer, this));
	auto Setting = MenuItemImage::create(
		"Image/HelloWorldScene/Setting_normal.png",
		"Image/HelloWorldScene/Setting_selected.png",
		CC_CALLBACK_1(HelloWorld::toSettingScene, this));
	auto Exit = MenuItemImage::create(
		"Image/HelloWorldScene/Exit_normal.png",
		"Image/HelloWorldScene/Exit_selected.png",
		CC_CALLBACK_1(HelloWorld::menuCloseCallback, this));
	auto GameMenu = Menu::create(NewGame, Load, Help, Setting, Exit, NULL);
	GameMenu->setPosition(Director::getInstance()->getVisibleSize().width / 2, Director::getInstance()->getVisibleSize().height / 2);
	GameMenu->alignItemsVerticallyWithPadding(30);
	this->addChild(GameMenu, 1);

	auto keyboardLs = EventListenerKeyboard::create();
	keyboardLs->onKeyPressed = [=](EventKeyboard::KeyCode code, Event*event){
		if (code == MOVE_UP)
		{
			CCLOG("UP");
		}
	};
	keyboardLs->onKeyReleased = [](EventKeyboard::KeyCode code, Event*event){
		CCLOG("BBB");
	};
	_eventDispatcher->addEventListenerWithSceneGraphPriority(keyboardLs, this);

    return true;
}

void HelloWorld::menuCloseCallback(Ref* pSender)
{
	Director::getInstance()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
	exit(0);
#endif
}

void HelloWorld::PopHelpLayer(Ref* pSender){
	HelpLayer* popLayer = HelpLayer::create();
	this->addChild(popLayer, 4);
}

void HelloWorld::toSettingScene(Ref* pSender) {
	Director::getInstance()->replaceScene(TransitionShrinkGrow::create(0.2f, SettingScene::createScene()));
}

void HelloWorld::toLoadScene(Ref* pSender) {
	Director::getInstance()->replaceScene(TransitionShrinkGrow::create(0.2f, LoadScene::createScene()));
}

void HelloWorld::toRoundFirst(cocos2d::Ref* pSender) {
	Director::getInstance()->replaceScene(TransitionShrinkGrow::create(0.2f, GameScene::createScene()));
}