#ifndef __MONSTER1_H__
#define __MONSTER1_H__
#include "Monster.h"
USING_NS_CC;
class Monster1:public Monster {
	public:
		Monster1(void);
		virtual void turnOnActive();    //ת����ŭ״̬
	    virtual void turnOffActive();  //ת���Ǽ�ŭ״̬
		void rush(float); 
		CREATE_FUNC(Monster1);
};

#endif