#include "GameConstants.h"

int g_passLevelCount = 0;
int g_currentLevel = 1;

cocos2d::EventKeyboard::KeyCode MOVE_UP = cocos2d::EventKeyboard::KeyCode::KEY_W;
cocos2d::EventKeyboard::KeyCode MOVE_DOWN = cocos2d::EventKeyboard::KeyCode::KEY_S;
cocos2d::EventKeyboard::KeyCode MOVE_LEFT = cocos2d::EventKeyboard::KeyCode::KEY_A;
cocos2d::EventKeyboard::KeyCode MOVE_RIGHT = cocos2d::EventKeyboard::KeyCode::KEY_D;
cocos2d::EventKeyboard::KeyCode PICK = cocos2d::EventKeyboard::KeyCode::KEY_Q;
cocos2d::EventKeyboard::KeyCode ATTACK = cocos2d::EventKeyboard::KeyCode::KEY_J;
cocos2d::EventKeyboard::KeyCode JUMP = cocos2d::EventKeyboard::KeyCode::KEY_K;
cocos2d::EventKeyboard::KeyCode SHOP = cocos2d::EventKeyboard::KeyCode::KEY_P;
cocos2d::EventKeyboard::KeyCode PROP1 = cocos2d::EventKeyboard::KeyCode::KEY_N;
cocos2d::EventKeyboard::KeyCode PROP2 = cocos2d::EventKeyboard::KeyCode::KEY_M;
cocos2d::EventKeyboard::KeyCode SKILL1 = cocos2d::EventKeyboard::KeyCode::KEY_U;
cocos2d::EventKeyboard::KeyCode SKILL2 = cocos2d::EventKeyboard::KeyCode::KEY_I;
cocos2d::EventKeyboard::KeyCode SKILL3 = cocos2d::EventKeyboard::KeyCode::KEY_O;

cocos2d::EventKeyboard::KeyCode CovertToKeyCode(const char* s) {
	if (strcmp(s, "a") == 0 || strcmp(s, "A") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_A;
	if (strcmp(s, "b") == 0 || strcmp(s, "B") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_B;
	if (strcmp(s, "c") == 0 || strcmp(s, "C") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_C;
	if (strcmp(s, "d") == 0 || strcmp(s, "D") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_D;
	if (strcmp(s, "e") == 0 || strcmp(s, "E") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_E;
	if (strcmp(s, "f") == 0 || strcmp(s, "F") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_F;
	if (strcmp(s, "g") == 0 || strcmp(s, "G") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_G;
	if (strcmp(s, "h") == 0 || strcmp(s, "H") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_H;
	if (strcmp(s, "i") == 0 || strcmp(s, "I") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_I;
	if (strcmp(s, "j") == 0 || strcmp(s, "J") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_J;
	if (strcmp(s, "k") == 0 || strcmp(s, "K") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_K;
	if (strcmp(s, "l") == 0 || strcmp(s, "L") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_L;
	if (strcmp(s, "m") == 0 || strcmp(s, "M") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_M;
	if (strcmp(s, "n") == 0 || strcmp(s, "N") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_N;
	if (strcmp(s, "o") == 0 || strcmp(s, "O") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_O;
	if (strcmp(s, "p") == 0 || strcmp(s, "P") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_P;
	if (strcmp(s, "q") == 0 || strcmp(s, "Q") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_Q;
	if (strcmp(s, "r") == 0 || strcmp(s, "R") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_R;
	if (strcmp(s, "s") == 0 || strcmp(s, "S") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_S;
	if (strcmp(s, "t") == 0 || strcmp(s, "T") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_T;
	if (strcmp(s, "u") == 0 || strcmp(s, "U") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_U;
	if (strcmp(s, "v") == 0 || strcmp(s, "V") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_V;
	if (strcmp(s, "w") == 0 || strcmp(s, "W") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_W;
	if (strcmp(s, "x") == 0 || strcmp(s, "X") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_X;
	if (strcmp(s, "y") == 0 || strcmp(s, "Y") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_Y;
	if (strcmp(s, "z") == 0 || strcmp(s, "Z") == 0)
		return cocos2d::EventKeyboard::KeyCode::KEY_Z;
	return cocos2d::EventKeyboard::KeyCode::KEY_SPACE;
}

cocos2d::Texture2D* ScreenCaptureTexture = NULL;