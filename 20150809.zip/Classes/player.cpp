#include "player.h"
Player::Player() {
	InitActorSprite("img/animation/Players/stand_right1.png",Rect(0,0,43,71));

	myAnimation runAni = myAnimation::createWithPlist("walk_right", 4, true);
	runAni.setSpeed(0.2f);
	SetAnimation(status::run, runAni);

	myAnimation attackani = myAnimation::createWithPlist("swing_right", 4, false);
	attackani.animFrames.pushBack( CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("walk_right0.png"));
	attackani.setSpeed(0.2f);
	SetAnimation(status::attack, attackani);

	myAnimation deadAni = myAnimation::createWithPlist("stand_right", 5, true);
	deadAni.setSpeed(0.2f);
	SetAnimation(status::dead, deadAni);

	skill1Ani = myAnimation::createWithPlist("effect_right", 9, false);
	skill1Ani.setSpeed(0.2f);

	skill2Ani = myAnimation::createWithPlist("skill2_", 9, false);
	skill2Ani.setSpeed(0.1f);

	skill3Ani = myAnimation::createWithPlist("skill1_right", 10, false);
	skill3Ani.setSpeed(0.2f);

	skillAni = myAnimation::createWithPlist("skill0_right", 3, false);

	physicsbody -> setCategoryBitmask(1);
	physicsbody -> setContactTestBitmask(142);
	physicsbody -> setCollisionBitmask(18);
	
	life = 100;
	power = 50;
	defence = 0;
	cd_1 = 6.0f;
	cd_2 = 8.0f;
	cd_3 = 12.0f;
	leave_cd_1 = 0.0f;
	leave_cd_2 = 0.0f;
	leave_cd_3 = 0.0f;
	schedule(schedule_selector(Player::updateCD), 0.2f);
	//m_AttackSprite -> setTexture(TextureCache::sharedTextureCache()->addImage("img/animation/test.png"));
	//m_AttackSprite -> setTextureRect(Rect(0,0,50,textureRect.getMaxY()));
	m_SkillSprite = NULL;
	m_AttackSprite -> setTag(ATTACK_TAG);
}
void Player::updateCD(float dt) {
	if(leave_cd_1 >= 0.1)
		leave_cd_1 -= 0.2;
	if(leave_cd_2 >= 0.1)
		leave_cd_2 -= 0.2;
	if(leave_cd_3 >= 0.1)
		leave_cd_3 -= 0.2;
}
void Player::playSkill(int num) {
	CHECK_ABLE;
	CHECK_GROUND;
	StopRunning();
	PhysicsBody* AttackBox;
	switch(num) {
		case 1:
			if(leave_cd_1 > 0.1) return;
			
			leave_cd_1 = cd_1;

			Status = skill1;
			currentStatus = skill1;
			isAble = false;

			m_SkillSprite = Sprite::create();
			AttackBox = PhysicsBody::createBox(Size(150,textureRect.getMaxY()));
			AttackBox -> setGravityEnable(false);
			AttackBox -> setCategoryBitmask(64);
			AttackBox -> setContactTestBitmask(4);
			AttackBox -> setCollisionBitmask(0);
			m_SkillSprite -> setPhysicsBody(AttackBox);
			m_SkillSprite -> setTag(ATTACK_TAG);
			this->addChild(m_SkillSprite);
			m_SkillSprite -> setPositionX(80*position);
			m_SkillSprite -> setRotationY(90 - 90*position);
			AttackBox -> setPositionOffset(Vec2(50*position,0));

			m_ActorSprite -> runAction(skillAni.getAnimation());
			m_SkillSprite -> runAction(skill1Ani.getAnimation());

			skillStep = 0;
			isAttackValid = false;
			schedule(schedule_selector(Player::playSkill1), 0.2f, 8, 0.2f);
			break;
		case 2:
			if(leave_cd_2 > 0.1) return;
			leave_cd_2 = cd_2;

			Status = skill2;
			currentStatus = skill2;
			isAble = false;
			m_SkillSprite = Sprite::create();
			this->addChild(m_SkillSprite);
			m_SkillSprite -> setPositionY(20);
			m_SkillSprite -> runAction(skill2Ani.getAnimation());
			schedule(schedule_selector(Player::playSkill2), 0.2f, 0, 0.9f);
			break;
		case 3:
			if(leave_cd_3 > 0.1) return;
			leave_cd_3 = cd_3;

			Status = skill3;
			currentStatus = skill3;
			isAble = false;
			m_SkillSprite = Sprite::create();
			this->addChild(m_SkillSprite);
			m_SkillSprite -> setPositionY(50);

			skillStep3 = 0;
			m_SkillSprite -> runAction(skill3Ani.getAnimation());
			schedule(schedule_selector(Player::playSkill3), 5.0f, 3, 2.0f);
			break;
	}
}
void Player::playSkill1(float dt) {
	skillStep ++;
	if(skillStep == 3) {
		isAttackValid = true;
	}
	else if(skillStep == 6){
		
		isAttackValid = false;
	}
	if(skillStep >= 9) {
		isAble = true;
		REMOVE_SKILL;
	}
}
void Player::playSkill2(float dt) {
	REMOVE_SKILL;
	isAble = true;
	life += 10;
}
void Player::playSkill3(float dt) {
	skillStep3 ++;
	if(skillStep3 == 1) {
		isAble = true;
		REMOVE_SKILL;
		m_ActorSprite -> setColor(Color3B::MAGENTA);
		AddActorValue(Vec3(0,20,-20));
	} else if(skillStep3 == 3) {
		m_ActorSprite -> setColor(Color3B::WHITE);
		AddActorValue(Vec3(0,-20,20));
	}
	
	
}
