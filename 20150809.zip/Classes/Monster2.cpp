#include "Monster2.h"

Monster2::Monster2() {
	InitActorSprite("img/animation/monkey/stand_right0.png",Rect(0,0,73,66));

	myAnimation runAni = myAnimation::createWithPlist("m2_move_right", 6, true);
	runAni.setSpeed(0.3f);
	SetAnimation(status::run, runAni);

	myAnimation deadani = myAnimation::createWithPlist("m2_die_right", 8, false);
	deadani.setSpeed(0.3f);
	SetAnimation(status::dead, deadani);

	myAnimation attackani = myAnimation::createWithPlist("m2_skill_right", 10, false);
	attackani.setSpeed(0.2f);
	SetAnimation(status::attack, attackani);

	peachAni = myAnimation::createWithPlist("m2_skill_attachment", 4, true);
	peachAni.setSpeed(0.1f);

	//setScale(0.6);

	VelocityX = 40;
	life = 100;
	power = 20;
	defence = 0;

	Run();
}

void Monster2::turnOnActive() {
	isActive = true;
	schedule(schedule_selector(Monster2::shoot), 2.0f, 1000, 0.2f);
}

void Monster2::turnOffActive() {
	isActive = false;
	unschedule(schedule_selector(Monster2::shoot));
}



void Monster2::shoot(float dt) {
	StopRunning();
	position = (player -> getPosition().x < getPosition().x)?-1:1;
	Attack();
	schedule(schedule_selector(Monster2::addBullet), 0.8f, 0, 0.8f);
}

void Monster2::addBullet(float dt) {
	CHECK_ABLE;
	Sprite* Bullet = Sprite::create();
	PhysicsBody* bulletbody = PhysicsBody::createBox(Size(20, 20),
		PhysicsMaterial(0.1f, 0.0f, 0.0f));
	bulletbody -> setGravityEnable(false);
	bulletbody -> setVelocity(Vec2(300*position,0));
	bulletbody -> setCategoryBitmask(128);
	bulletbody -> setContactTestBitmask(19);
	bulletbody -> setCollisionBitmask(0);
	Bullet -> setPhysicsBody(bulletbody);
	Bullet -> setTag(BULLET_TAG);
	addChild(Bullet);
	Bullet -> runAction(peachAni.getAnimation());
}