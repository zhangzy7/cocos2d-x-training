#ifndef __MONSTER2_H__
#define __MONSTER2_H__
#include "Monster.h"
#define BULLET_TAG  6
USING_NS_CC;
class Monster2:public Monster {
	public:
		myAnimation peachAni;
		Monster2(void);
		virtual void turnOnActive();    //ת����ŭ״̬
	    virtual void turnOffActive();  //ת���Ǽ�ŭ״̬
		void shoot(float);
		void addBullet(float);
		CREATE_FUNC(Monster2);
};

#endif