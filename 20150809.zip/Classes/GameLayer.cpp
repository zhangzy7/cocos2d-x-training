#include "GameLayer.h"
#define SPRITEA_B(tag) (spriteA -> getTag() == tag)?spriteA:spriteB
#define _SPRITEA_B(tag) (spriteA -> getTag() != tag)?spriteA:spriteB
GameLayer::GameLayer() {
	this->scheduleUpdate();
}
GameLayer::~GameLayer() { }

bool GameLayer::init() {	
	//TMX��ͼ
	//_map = TMXTiledMap::create("img/bg/RoundSecond.tmx");
	_map = TMXTiledMap::create("img/bg/RoundFirst.tmx");
	locX = 0;
	//_map -> setScale(2);
	_edge = _map->layerNamed("edge");
	_wall = _map->layerNamed("walls");
	_hazard = _map->layerNamed("final");
	this -> addChild(_map, 1);

	//Ϊ��ͼ������������
	CreateBox();
	
	/***************
	 *                  player      wall       monster     props     border   edge   Attack  bullet
	 *  Category          1          2          4           8         16       32      64      128
		ContactTest      142       133         99           1         128      4       4        19
		Collision        18         15          2           2         1        0       0		0
	 ****************/
	
	//����һ�����
	player = Player::create();
	player -> setPosition(Vec2(64,160));
	player->setTag(PLAYER_TAG);
	this -> addChild(player, 2);

	//���ӹ���
	CreateMonster();

	//���̼�����
	auto listener = EventListenerKeyboard::create();
	listener->onKeyPressed = CC_CALLBACK_2(GameLayer::onKeyPressed, this);
	listener->onKeyReleased = CC_CALLBACK_2(GameLayer::onKeyReleased, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);

	//��ײ������
	auto physicslistener = EventListenerPhysicsContact::create();
	physicslistener->onContactBegin = CC_CALLBACK_1(GameLayer::onContactBegin, this);
	physicslistener->onContactSeperate = CC_CALLBACK_1(GameLayer::onContactSeperate, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(physicslistener, this);


	return true;
}
void GameLayer::onKeyPressed(EventKeyboard::KeyCode keyCode, Event* event) {
    if(MOVE_RIGHT == keyCode) {
		player -> position = 1;
		player -> Run();
	} else if(MOVE_LEFT == keyCode) {
		player -> position = -1;
		player -> Run();
	} else if(JUMP == keyCode) {
		player -> Jump();
	} else if(ATTACK == keyCode) {
		player -> Attack();
	}else if(SKILL1 == keyCode) {
		player -> playSkill(1);
	}else if(SKILL2 == keyCode) {
		player -> playSkill(2);
	} else if(SKILL3 == keyCode) {
		player -> playSkill(3);
	} else if(EventKeyboard::KeyCode::KEY_ESCAPE == keyCode) {
		Size visibleSize = Director::getInstance()->getVisibleSize();
		RenderTexture *renderTexture = CCRenderTexture::create(visibleSize.width,visibleSize.height);
		renderTexture->begin(); 
		this->getParent()->visit();
		renderTexture->end();
		Director::sharedDirector()->pushScene(GamePauseScene::createScene(renderTexture));
	}
}

void GameLayer::onKeyReleased(EventKeyboard::KeyCode keyCode, Event* event) {
	if((EventKeyboard::KeyCode::KEY_D == keyCode && player -> position == 1) ||
		(EventKeyboard::KeyCode::KEY_A == keyCode && player -> position == -1)) {
		player -> StopRunning();
	}
}

//��ײ���ص�����
bool GameLayer::onContactBegin(const PhysicsContact& contact) {
	auto spriteA = (Sprite*)contact.getShapeA()->getBody()->getNode();                 
    auto spriteB = (Sprite*)contact.getShapeB()->getBody()->getNode();
	auto data    = contact.getContactData() -> normal;
	if (spriteA && spriteB) {
		//����������ײ
		if((spriteA -> getTag() == PLAYER_TAG && spriteB -> getTag() == WALL_TAG) ||
			(spriteB -> getTag() == PLAYER_TAG && spriteA -> getTag() == WALL_TAG)) {
			if(data.y > 0.5 && data.y < 1.5)
				player -> onGround = true;
		}
		//�����������ײ
		else if((spriteA -> getTag() == MONSTER_TAG && spriteB -> getTag() == WALL_TAG) ||
			(spriteB -> getTag() == MONSTER_TAG && spriteA -> getTag() == WALL_TAG)) {
			if(data.y > 0.5 && data.y < 1.5) {
				((Monster*)(SPRITEA_B(MONSTER_TAG))) -> onGround = true;
			}
		}
		//�������Ե��ײ
		else if((spriteA -> getTag() == MONSTER_TAG && spriteB -> getTag() == EDGE_TAG) ||
			(spriteB -> getTag() == MONSTER_TAG && spriteA -> getTag() == EDGE_TAG)) {
				Monster* monster = (Monster*)(SPRITEA_B(MONSTER_TAG));
				if(!(monster -> isActive)) {
					monster -> position *= -1;
					monster -> Run();
				}
		}
		//��������ҵ���ײ
		else if((spriteA -> getTag() == PLAYER_TAG && spriteB -> getTag() == MONSTER_TAG) ||
			(spriteB -> getTag() == PLAYER_TAG && spriteA -> getTag() == MONSTER_TAG)) {
				Monster* mon = (Monster*)(SPRITEA_B(MONSTER_TAG));
				player->life -= mon->power - player->defence;
				if(player->life <= 0) {
					player->StopRunning();
					//player->removeFromPhysicsWorld();
					//player->Status = Actor::status::dead;
					//gameover
				} else {
					player->HitBack(player->getPositionX() - mon->getPosition().x);
				}
		}
		//��������ҹ�����Χ����ײ
		else if((spriteA -> getTag() == ATTACK_TAG && spriteB -> getTag() == MONSTER_TAG) ||
			(spriteB -> getTag() == ATTACK_TAG && spriteA -> getTag() == MONSTER_TAG)) {
				Monster* monster = (Monster*)(SPRITEA_B(MONSTER_TAG));
				monster -> isInrange = true;
		}
		//��������ҵ���ײ
		else if((spriteA -> getTag() == PROP_TAG && spriteB -> getTag() == PLAYER_TAG) ||
			(spriteB -> getTag() == PROP_TAG && spriteA -> getTag() == PLAYER_TAG)) {
				Prop* prop = (Prop*)(SPRITEA_B(PROP_TAG));
				player -> AddActorValue( prop->value );
				prop -> removeProp();
		}
		//�ӵ�������߽硢ǽ����ײ
		else if(spriteA -> getTag() == BULLET_TAG || spriteB -> getTag() == BULLET_TAG) {
				auto bullet = SPRITEA_B(BULLET_TAG);
				auto other = _SPRITEA_B(BULLET_TAG);
				if(other -> getTag() == PLAYER_TAG) {
					player->life -= ((Monster*)bullet->getParent())->power - player->defence;
					if(player->life <= 0) {
						player->StopRunning();
					} else {
						player->HitBack( bullet->getPhysicsBody()->getVelocity().x );
					}
				}
				CC_SAFE_RETAIN(bullet);
				bullet -> removeFromParent();
		}
    }
	return true;
}
void GameLayer::onContactSeperate(const PhysicsContact& contact) {
	auto spriteA = (Sprite*)contact.getShapeA()->getBody()->getNode();                 
    auto spriteB = (Sprite*)contact.getShapeB()->getBody()->getNode();
	auto data    = contact.getContactData() -> normal;
	if((spriteA -> getTag() == ATTACK_TAG && spriteB -> getTag() == MONSTER_TAG) ||
			(spriteB -> getTag() == ATTACK_TAG && spriteA -> getTag() == MONSTER_TAG)) {
			if(spriteA -> getTag() == MONSTER_TAG) {
				((Monster*)spriteA) -> isInrange = false;
			} else {
				((Monster*)spriteB) -> isInrange = false;
			}	
	}

}
//���ӹ���
void GameLayer::CreateMonster() {
	//TMXLayer* _monster = _map -> layerNamed("monster");
	TMXObjectGroup* objectGroup = _map->getObjectGroup("monster");  
    ValueVector object = objectGroup->getObjects();
	for (ValueVector::iterator it = object.begin(); it != object.end(); it++) {
		ValueMap m = (*it).asValueMap();
		//����һ������
		for(int i=0; i < m.at("amount").asInt(); i++) {
			Monster* monster;
			if(m.at("type").asInt() == 1)
				monster =  Monster1::create();
			else if(m.at("type").asInt() == 2)
				monster = Monster2::create();
			monster -> player = player;
			monster -> setPosition(Vec2(m.at("x").asFloat(),m.at("y").asFloat()));
			monster -> setTag(MONSTER_TAG);
			monster -> initMonster();
			this -> addChild(monster, 1);
		}
	}
}

//ΪTMX��ͼ������������
void GameLayer::CreateBox() {
	for(int i=0; i < (int)(_map->getMapSize().height); i++) {
		int num = 0;
		Sprite* tmp = NULL;
		for(int j=0; j < (int)(_map->getMapSize().width); j++) {
			log("ditu:%d %d", i,j);
			auto tile = _wall->getTileAt(Vec2(j,i));
			auto edge = _edge->getTileAt(Vec2(j,i));
			//auto tile2 = _hazard->getTileAt(Vec2(i,j));
			if(tile) {
				num ++;
				if(tmp == NULL)	tmp = tile;
			} else if(num != 0) {
				CreateBoxForTile(tmp, WALL_TAG, num, Vec3(2,133,15));
				num = 0;
				tmp = NULL;
			}
			if(edge) {
				CreateBoxForTile(edge, EDGE_TAG, 1, Vec3(32,4,0));
			}
		}
		if(tmp != NULL) {
			CreateBoxForTile(tmp, WALL_TAG, num, Vec3(2,133,15));
			num = 0;
			tmp = NULL;
		}
	}
}
//Ϊһ����Ƭ������������
void GameLayer::CreateBoxForTile(Sprite* tile, int tag, int num, Vec3 bitmask) {
	tile -> setPositionX(tile -> getPositionX()+ tile -> getContentSize().width/2);
	tile -> setPositionY(tile -> getPositionY()+ tile -> getContentSize().height/2);
	tile -> setTag(tag);
	auto physicsbody = PhysicsBody::createEdgeBox(Size(_map->getTileSize().width*num,_map->getTileSize().height),
	PhysicsMaterial(0.0f, 0.0f, 0.0f));
	physicsbody -> setGravityEnable(false);
	physicsbody -> setDynamic(false);
	physicsbody -> setCategoryBitmask(bitmask.x);
	physicsbody -> setContactTestBitmask(bitmask.y);
	physicsbody -> setCollisionBitmask(bitmask.z); 
	tile->setPhysicsBody(physicsbody);

	physicsbody -> setPositionOffset(Vec2(_map->getTileSize().width * (num - 1) / 2, 0));

}
//�ӵ����
void GameLayer::setViewpointCenter(cocos2d::Point pos, float dt) {
	Size visibleSize = Director::getInstance()->getVisibleSize();
	//�޶���ɫ���ܳ�������
	if(pos.x > visibleSize.width/2) {
		locX -= pos.x - visibleSize.width/2;
		float offset = locX;
		if(locX < visibleSize.width - _map->getMapSize().width * _map->getTileSize().width) {
			locX = visibleSize.width - _map->getMapSize().width * _map->getTileSize().width ;
		}
		offset = locX-offset;
		_map->setPositionX(locX);
		player -> setPositionX(visibleSize.width/2 + offset);

		Vector<Node*> vec = getChildren();
		for(int i=0; i < vec.size(); i++) {
			if(vec.at(i)->getTag() == MONSTER_TAG || vec.at(i)->getTag() == PROP_TAG)
				vec.at(i) -> setPositionX(visibleSize.width/2 + offset + (vec.at(i)->getPositionX() - pos.x));
		}
	}
}

void GameLayer::update(float dt) {
	this->setViewpointCenter(player->getPosition(), dt);
}




