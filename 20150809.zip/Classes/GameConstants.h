#ifndef __GameConstants__
#define __GameConstants__

#ifndef __GameConstants_h__
#define __GameConstants_h__

#include "cocos2d.h"

typedef enum{
	kAlreadyPass,
	kNotPassYet,
	kLockLevel
}LevelItemType;


const char PlayerPassLevelCountKey[] = "PlayerPassLevelCountKey";

const float g_maxLevel = 45;
const int g_EachPageCount = 15;
const float g_EachLineCount = 5;
const int levelMarginX = 113;
const int levelMarginY = 134;
extern int g_passLevelCount;
extern int g_currentLevel;
// demo operation key
extern cocos2d::EventKeyboard::KeyCode MOVE_UP;
extern cocos2d::EventKeyboard::KeyCode MOVE_DOWN;
extern cocos2d::EventKeyboard::KeyCode MOVE_LEFT;
extern cocos2d::EventKeyboard::KeyCode MOVE_RIGHT;
extern cocos2d::EventKeyboard::KeyCode PICK;
extern cocos2d::EventKeyboard::KeyCode ATTACK;
extern cocos2d::EventKeyboard::KeyCode JUMP;
extern cocos2d::EventKeyboard::KeyCode SHOP;
extern cocos2d::EventKeyboard::KeyCode PROP1;
extern cocos2d::EventKeyboard::KeyCode PROP2;
extern cocos2d::EventKeyboard::KeyCode SKILL1;
extern cocos2d::EventKeyboard::KeyCode SKILL2;
extern cocos2d::EventKeyboard::KeyCode SKILL3;

cocos2d::EventKeyboard::KeyCode CovertToKeyCode(const char* s);

extern cocos2d::Texture2D* ScreenCaptureTexture;

#endif

#endif