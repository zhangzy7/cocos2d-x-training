#ifndef __GAMEPAUSESCENE_SCENE_H__
#define __GAMEPAUSESCENE_SCENE_H__
#include "cocos2d.h"
USING_NS_CC;
class GamePauseScene : public cocos2d::Layer {
	public:
		static cocos2d::Scene* createScene(RenderTexture*);
		virtual bool init();
		void onKeyPressed(EventKeyboard::KeyCode, Event*); 
		CREATE_FUNC(GamePauseScene);
};

#endif