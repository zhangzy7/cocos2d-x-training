#include "Monster1.h"

Monster1::Monster1() {
	InitActorSprite("img/animation/Mushroom/stand_right0.png",Rect(0,0,63,58));

	myAnimation runAni = myAnimation::createWithPlist("m1_move_right", 3, true);
	runAni.setSpeed(0.3f);
	SetAnimation(status::run, runAni);

	myAnimation deadani = myAnimation::createWithPlist("m1_die_right", 3, false);
	deadani.setSpeed(0.3f);
	SetAnimation(status::dead, deadani);

	//myAnimation attackani = myAnimation::createWithPlist("skill_right", 8, false);
	//deadani.setSpeed(0.2f);
	//SetAnimation(status::attack, attackani);

	//setScale(0.6);

	VelocityX = 40;
	life = 100;
	power = 20;
	defence = 0;

	Run();
}

void Monster1::turnOnActive() {
	m_ActorSprite -> setColor(ccc3(200, 255, 255));
	AddActorValue(Vec3(0, 10, 10));
	VelocityX += 40;
	isActive = true;
	schedule(schedule_selector(Monster1::rush), 0.8f, 1000, 1.6f);
}

void Monster1::rush(float dt) {
	position = (player -> getPosition().x < getPosition().x)?-1:1;
	Run();
}

void Monster1::turnOffActive() {
	m_ActorSprite -> setColor(Color3B::WHITE);
	AddActorValue(Vec3(0, -10, -10));
	VelocityX -= 40;
	isActive = false;
	unschedule(schedule_selector(Monster1::rush));
}
