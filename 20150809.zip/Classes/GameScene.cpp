#include "GameScene.h"

USING_NS_CC;

Scene* GameScene::createScene() {
    auto scene = Scene::createWithPhysics();
	scene -> getPhysicsWorld() -> setGravity(Vec2(0,-600));
    auto layer = GameScene::create();
    scene->addChild(layer);
	SimpleAudioEngine::sharedEngine()->playBackgroundMusic(GAME_MUSIC_FILE, true);
    return scene;
}

// on "init" you need to initialize your instance
bool GameScene::init()
{
    if ( !Layer::init() ) return false;
    Size visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();
	Size winSize = Director::getInstance()->getWinSize();
	log("%f %f %f\n",visibleSize.height,origin.y,winSize.height);
    auto closeItem = MenuItemImage::create(
                                           "CloseNormal.png",
                                           "CloseSelected.png",
                                           CC_CALLBACK_1(GameScene::menuCloseCallback, this));
    
	closeItem->setPosition(Vec2(origin.x + visibleSize.width - closeItem->getContentSize().width/2 ,
                                origin.y + closeItem->getContentSize().height/2));
    auto menu = Menu::create(closeItem, NULL);
    menu->setPosition(Vec2::ZERO);
    this->addChild(menu, 1);

	//��Դ�ļ�����
	 CCTexture2D::PVRImagesHavePremultipliedAlpha(true);
	 CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("img/animation/HeiShiTouRen/movements.plist");
	 CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("img/animation/player/player.plist");
	 CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("img/animation/Mushroom/movements.plist");
	 CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("img/animation/monkey/monkey.plist");

    //my code
	//����
	auto background = Sprite::create(GAME_BG_FILE);
	//background->setContentSize(Size(visibleSize.width , visibleSize.height * 0.8));
	//background->getTexture()->setTexParameters();
    background->setPosition(Vec2(visibleSize.width/2 + origin.x, visibleSize.height/2 + origin.y));
    this->addChild(background, 0);
	/********************/

	//�����߽�
	auto body = PhysicsBody::createEdgeBox(visibleSize, PhysicsMaterial(0.0f, 0.0f, 0.3f), 3);
	body->setCategoryBitmask(16);
	body->setContactTestBitmask(128);
	body->setCollisionBitmask(1);
	auto edgeNode = Node::create();
	edgeNode->setPosition(Point(visibleSize.width/2,visibleSize.height/2));
	edgeNode->setPhysicsBody(body);
	this->addChild(edgeNode);
	/********************/

	//��Ϸ���Ʋ�
	auto gamelayer = GameLayer::create();
	gamelayer->setName("gamelayer");
	this->addChild(gamelayer,1);
	/********************/

	auto guilayer = GuiLayer::create();
	guilayer->setName("guilayer");
	this->addChild(guilayer, 3);

	this->scheduleUpdate();
	return true;
}

void GameScene::update(float dt) {
	Player* player = ((GameLayer*)(this->getChildByName("gamelayer")))-> player;
	//��������ֵ
	int life = player -> life;
	((ControlSlider*)((GuiLayer*)(this->getChildByName("guilayer"))->getChildByTag(20))) -> setValue(life);
	((GuiLayer*)(this->getChildByName("guilayer"))) -> showSkillCooling(1, player -> leave_cd_1 / (double)(player -> cd_1) * 100);
	((GuiLayer*)(this->getChildByName("guilayer"))) -> showSkillCooling(2, player -> leave_cd_2 / (double)(player -> cd_2) * 100);
	((GuiLayer*)(this->getChildByName("guilayer"))) -> showSkillCooling(3, player -> leave_cd_3 / (double)(player -> cd_3) * 100);
}

void GameScene::menuCloseCallback(Ref* pSender) {
    Director::getInstance()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
}



