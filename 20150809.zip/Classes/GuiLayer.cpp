#include "GuiLayer.h" 
GuiLayer::GuiLayer() {}
GuiLayer::~GuiLayer() {}
bool GuiLayer::init() {
    Size visibleSize = Director::getInstance()->getVisibleSize();
	auto slide_control = ControlSlider::create(BLOOD_BG,BLOOD_PROCESS,BLOOD_SLIDERTHUMB);
	slide_control->setMinimumValue(0.0f);//������Сֵ
	slide_control->setMaximumValue(100.0f);//�������ֵ
	slide_control->setValue(70.0f);//���ó�ʼֵ
	slide_control->setTag(20);
	slide_control->setScale(1.5);
	slide_control->setPosition(Point(150,visibleSize.height-50));
	//slide_control->addTargetWithActionForControlEvents(this,cccontrol_selector(HelloWorld::slideCallback),Control::EventType::VALUE_CHANGED);//�����϶��ص�	
	this->addChild(slide_control,2);


	CCSprite *cool1 = CCSprite::create("img/skill/skill1_normal.png");
	this->addChild(cool1, 0);  
	cool1 -> setPosition(Point(32,visibleSize.height-100));
	CCSprite *active1 = CCSprite::create("img/skill/skill1_cooling.png");
	progressCD1 = CCProgressTimer::create(active1);  
	progressCD1->setPosition(Point(32,visibleSize.height-100));
	progressCD1->setType(CCProgressTimerType::RADIAL);
	this->addChild(progressCD1, 1);

	CCSprite *cool2 = CCSprite::create("img/skill/skill2_normal.png");
	this->addChild(cool2, 0);  
	cool2 -> setPosition(Point(70,visibleSize.height-100));
	CCSprite *active2 = CCSprite::create("img/skill/skill2_cooling.png");
	progressCD2 = CCProgressTimer::create(active2);  
	progressCD2->setPosition(Point(70,visibleSize.height-100));
	progressCD2->setType(CCProgressTimerType::RADIAL);
	this->addChild(progressCD2, 2);

	CCSprite *cool3 = CCSprite::create("img/skill/skill3_normal.png");
	this->addChild(cool3, 0);  
	cool3 -> setPosition(Point(108,visibleSize.height-100));
	CCSprite *active3 = CCSprite::create("img/skill/skill3_cooling.png");
	progressCD3 = CCProgressTimer::create(active3);  
	progressCD3->setPosition(Point(108,visibleSize.height-100));
	progressCD3->setType(CCProgressTimerType::RADIAL);
	this->addChild(progressCD3, 3);
	return true;
}

void GuiLayer::showSkillCooling(int skillnum, double time) {
	switch (skillnum) {
		case(1):
			progressCD1 -> setPercentage(time);
			break;
		case(2):
			progressCD2 -> setPercentage(time);
			break;
		case(3):
			progressCD3 -> setPercentage(time);
			break;
		default:
			break;
	}
	
}

