#ifndef __PROP_H__
#define __PROP_H__
#include "cocos2d.h"
using namespace cocos2d;
class Prop:public cocos2d::Node {
	public:
		PhysicsBody* physicsbody;  //��������
		Vec3 value;                //��������
		Prop();
		~Prop();
		void InitPropSprite(char*, Rect);
		void removeProp();
		static Prop* CreatePeach();
		CREATE_FUNC(Prop);
	private:
		Sprite* m_ActorSprite; //����
		

};
#endif