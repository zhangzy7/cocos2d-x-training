#include "myAnimation.h"
USING_NS_CC;
myAnimation myAnimation::createWithTexture(Texture2D *Texture, Vec2 framesize, int frameorder[], int framenum, bool isrepeat) {
	myAnimation obj;
	for(int i=0;i < framenum ;i++) {
		SpriteFrame* frame = SpriteFrame::createWithTexture(Texture,
			Rect(framesize.x * frameorder[i], 0, framesize.x, framesize.y));
		obj.animFrames.pushBack(frame); 
	}
	obj.time = 0.1f;
	obj.isrepeat = isrepeat;
	return obj;
}
myAnimation myAnimation::createWithPlist(char* str, int framenum, bool isrepeat = true) {
	myAnimation obj;
	char name[100] = {0};
	for(int i=0;i < framenum ;i++) {
		sprintf(name, "%s%i.png",str,i);
		log("%s", name);
		SpriteFrame* frame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(name);
		obj.animFrames.pushBack(frame); 
	}
	obj.time = 0.1f;
	obj.isrepeat = isrepeat;
	return obj;
}
myAnimation* myAnimation::setSpeed(float time) {
	this->time = time;
	return this;
}
Action* myAnimation::getAnimation() {
	Animation* animation = Animation::createWithSpriteFrames(animFrames, time);
	Action* n;
	if(isrepeat) {
		n =  RepeatForever::create(Animate::create(animation));
	} else {
		n = Repeat::create(Animate::create(animation), 1);
	}
	return n;
}


