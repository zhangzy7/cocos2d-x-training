#include "Monster.h"
Monster::Monster() {
	isInrange = false;
	isActive = false;
}
void Monster::initMonster() {
	physicsbody -> setCategoryBitmask(4);
	physicsbody -> setContactTestBitmask(99);
	physicsbody -> setCollisionBitmask(2);
	schedule(schedule_selector(Monster::AIControll), 0.8f);
	scheduleUpdate();
}
void Monster::AIControll(float dt) {
	if(!isActive) {
		if(abs(player->getPosition().x - getPosition().x) < 250 && 
				abs(player->getPosition().y - getPosition().y) < 50 &&
				  (player->getPosition().x - getPosition().x) * position > 0) {
			turnOnActive();
		}
		else {
			if(CCRANDOM_0_1() < 0.3) position *= -1;
			Run();
		}
	}
	else {
		if(abs(player->getPosition().x - getPosition().x) > 300  || 
				abs(player->getPosition().y - getPosition().y) > 50) {
			turnOffActive();
		}
	}
	
}
void Monster::update(float dt) {
	if(isInrange && currentStatus != status::hit && Status != status::hit) {
		if(player -> currentStatus == status::attack && player -> isAttackValid ) {
			life -= player->power - defence;
			if(life <= 0) {
				StopRunning();
				this->removeFromPhysicsWorld();
				Status = status::dead;
			} else {
				HitBack(getPosition().x - player->getPositionX());
			}
		} else if(player -> currentStatus == status::skill1 && player -> isAttackValid ) {
			life -= player->power*3 - defence;
			if(life <= 0) {
				StopRunning();
				this->removeFromPhysicsWorld();
				Status = status::dead;
			} else {
				HitBack(getPosition().x - player->getPositionX());
			}
		}
		
	}
}