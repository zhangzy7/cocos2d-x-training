//��Ϳ����ߺ���ճ��
var weee,docH,docW;
var shapeRef,layerRef;
var AI =1;// 	96 * 75 / 254;

try{
//var i = 1
var num = app.activeDocument.layers.length
if (num == 1 || !confirm("ok?")){
Error.runtimeError(8007);}
var width = app.activeDocument.width.value
var height = app.activeDocument.height.value
app.activeDocument.resizeCanvas(width + 2,height + 2)
var width = app.activeDocument.width.value
var height = app.activeDocument.height.value
    shapeRef = [ [0,0], [0,height], [width ,height], [width ,0] ]
    app.activeDocument.selection.select(shapeRef)
    var strokeColor = new SolidColor();
        strokeColor.cmyk.cyan = 20;
        strokeColor.cmyk.magenta = 90;
        strokeColor.cmyk.yellow = 50;
        strokeColor.cmyk.black = 50;
for (var i = 0; i < num; i++){
    activeDocument.activeLayer = app.activeDocument.layers[i]
    app.activeDocument.selection.stroke(strokeColor, 2, StrokeLocation.CENTER, ColorBlendMode.VIVIDLIGHT, 100, false);
}
app.activeDocument.selection.deselect()
app.activeDocument.resizeCanvas(width*app.activeDocument.layers.length,height)
for (var i = 0; i < num; i++){
    activeDocument.activeLayer = app.activeDocument.layers[app.activeDocument.layers.length-1-i]
    layerRef = activeDocument.activeLayer
    activeDocument.activeLayer.copy()
    shapeRef = [ [width * i,0], [width * i,height], [width * (i+1),height], [width * (i+1),0] ]
    app.activeDocument.selection.select(shapeRef)
    app.activeDocument.paste()
    app.activeDocument.selection.deselect()
    layerRef.remove()
}
app.activeDocument.mergeVisibleLayers()
}
catch(e){
//alert("brojen")
}