#ifndef __GAMESCENE_SCENE_H__
#define __GAMESCENE_SCENE_H__

#include "cocos2d.h"
#include "SimpleAudioEngine.h"
#include "GameLayer.h"
using namespace CocosDenshion;

#define GAME_MUSIC_FILE  "bgm/0.mp3"
#define GAME_BG_FILE     "img/bg/bg02.png"

class GameScene : public cocos2d::Layer	 {
public:
    static cocos2d::Scene* createScene();
    virtual bool init();
    void menuCloseCallback(cocos2d::Ref* pSender);
    CREATE_FUNC(GameScene);
};

#endif
