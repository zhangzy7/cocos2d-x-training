#include "tools.h"
using namespace cocos2d;

float max(float x, float y) {
	if(x > y) return x;
	return y;
}
float min(float x, float y) {
	if(x < y) return x;
	return y;
}
Rect Tools::RectInset(Rect &rect, float dx, float dy) {
	rect.origin.x += dx;
	rect.size.width -= dx * 2;
	rect.origin.y -= dy;    //��Сʱy��Ӧ�����£�IOS������ϵ��Cocos2d-x��һ����yԭ���������½Ƕ������Ͻ�
	rect.size.height -= dy * 2;
	return rect;
}
Rect Tools::RectOffset(Rect &rect, Point d) {
	rect.setRect(rect.getMinX() + d.x, rect.getMinY() + d.y, 
			rect.getMaxX() + d.x, rect.getMaxY() + d.y);
	return rect;
}
Rect Tools::intersectsRect(Rect rectA, Rect rectB) {
	float minx = max(rectA.getMinX(), rectB.getMinX());
	float miny = max(rectA.getMinY(), rectB.getMinY());

	float maxx = min(rectA.getMaxX(), rectB.getMaxX());
	float maxy = min(rectA.getMaxY(), rectB.getMaxY());

	return CCRectMake(minx, miny, maxx-minx, maxy-miny);
}