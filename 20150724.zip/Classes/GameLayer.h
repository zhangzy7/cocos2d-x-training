#ifndef __GAMELAYER_H__
#define __GAMELAYER_H__
#include "cocos2d.h"
#include "Actor.h"
#include "GamePauseScene.h"
#define PLAYER_TAG 0
#define WALL_TAG   1
#define HAZARD_TAG 2
using namespace cocos2d;
class GameLayer:public Layer {
	public:
		GameLayer();
		~GameLayer();
		virtual bool  init();
		void CreateBox();
		void CreateBoxForTile(Sprite*,int);
		void onKeyPressed(EventKeyboard::KeyCode, Event*);
		void onKeyReleased(EventKeyboard::KeyCode, Event*);
		bool onContactBegin(const PhysicsContact&);
		void setViewpointCenter(Point, float);
		void update(float dt);
		CREATE_FUNC(GameLayer);
	private:
		Actor* player;
		TMXTiledMap* _map;
		TMXLayer* _wall;
		TMXLayer* _hazard;
		float locX;
};
#endif