#include "Actor.h"
USING_NS_CC; 

Actor::Actor() {
}
Actor::~Actor() {
}
//����ͼƬ������Ӣ��
void Actor::InitActorSprite(char *actor_name, Rect rect) {
	//��ʼ������
	Actor_name = actor_name;
	texture = TextureCache::sharedTextureCache()->addImage(Actor_name);
	Status = currentStatus = stop;
	position = 0;
	VelocityX = 200;


	//�ܶ���֡����
	int runorder[6] =  { 0,1,2,3,4,5 };
	myAnimation animation(texture, Vec2(rect.getMaxX(),rect.getMaxY()) , runorder, 6);
	runAnimation = animation;
	
	auto texture2 = TextureCache::sharedTextureCache()->addImage("img/animation/elizabeth/png/$elizabeth_2.png");
	myAnimation animation2(texture2, Vec2(90,90) , runorder, 6, false);
	attackAnimation = animation2;

	//������������
	physicsbody = PhysicsBody::createBox(Size(rect.getMaxX() - 15, rect.getMaxY() - 15),
		PhysicsMaterial(0.1f, 0.0f, 0.0f));  //1��density���ܶȣ�2��restiution�����ԣ�3��friction��Ħ������
	physicsbody -> setGravityEnable(true);
	physicsbody->setRotationEnable(false);
	//physicsbody -> setVelocityLimit(250);
	this->setPhysicsBody(physicsbody);

	//���Ӿ������
	this->m_ActorSprite=Sprite::create();
	this->m_ActorSprite->setTexture(texture);
	this -> m_ActorSprite -> setTextureRect(rect);
	this->addChild(m_ActorSprite);

	//���ö�ʱ�� 0.01sִ��һ��
	this->schedule(schedule_selector(Actor::update1), 0.01f);
}

void Actor::RunToLeft() {
	//StopRunning();
	//this -> physicsbody -> applyForce(Vec2(-50000,0));
	this -> physicsbody -> setVelocity(Vec2(0-VelocityX,physicsbody -> getVelocity().y));
	position = -1;
	Status = run;
}
void Actor::RunToRight() {
	//StopRunning();
	//this -> physicsbody -> applyForce(Vec2(50000,0));
	this -> physicsbody -> setVelocity(Vec2(VelocityX,physicsbody -> getVelocity().y));
	position = 1;
	Status = run;
}
void Actor::StopRunning() {
	//this -> physicsbody -> resetForces();
	
	this -> physicsbody -> setVelocity(Vec2(0,physicsbody -> getVelocity().y));
	position = 0;
	Status = stop;
}

void Actor::Jump() {
	if(onGround && abs(physicsbody -> getVelocity().y) < 5) {
		this -> physicsbody -> setVelocity(Vec2(physicsbody->getVelocity().x, 350));
	}
	onGround = false;
	Status = jump;
}

void Actor::Attack() {
	Status = attack;
	
}
void Actor::update1(float dt) {
	//this -> physicsbody -> setVelocity(Vec2(position*VelocityX,physicsbody -> getVelocity().y));
	float vx = (float)physicsbody -> getVelocity().x;
	if(abs(vx) > 2) {
		if(position > 0)
			this -> m_ActorSprite -> setRotationY(180);
		else if(position < 0)
			this -> m_ActorSprite -> setRotationY(0);
	}
	SetAnimation();
}

void Actor::SetAnimation() {
	if(currentStatus == attack) {
		if(m_ActorSprite -> isFrameDisplayed(attackAnimation.animFrames.at(5))) {
			log("attack is done");
			
		} else {
			return;
		}
	}
	switch(this -> Status) {
		case status::run :
			if(currentStatus != run) {
				this -> m_ActorSprite -> runAction(runAnimation.setSpeed(0.1f) -> getAnimation());
				currentStatus = run;
			}
			break;
		case status::stop:
			this -> m_ActorSprite -> stopAllActions();
			this -> m_ActorSprite -> setTexture(texture);
			this -> m_ActorSprite -> setTextureRect(Rect(0,0,66,72));
			currentStatus = stop;
			break;
		case status::attack:
			StopRunning();
			this -> m_ActorSprite -> stopAllActions();
			if(currentStatus != attack) {
				this -> m_ActorSprite -> runAction(attackAnimation.setSpeed(0.1f) -> getAnimation());
			}
			currentStatus = attack;
			break;
		case status::jump:
			break;
	}
}

Rect Actor::collisionBoundingBox() {
	Rect collisionBox = Tools::RectInset(m_ActorSprite->getBoundingBox(), 3, 0);
	Rect returnBoundingBox = Tools::RectOffset(collisionBox, physicsbody -> getVelocity()); //������������ײ��,����Χ��x,y�᷽�����ƶ�diff.x, diff.y����λ
	return returnBoundingBox;
}
