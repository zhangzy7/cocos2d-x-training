#include "myAnimation.h"
USING_NS_CC;
myAnimation::myAnimation(Texture2D *playerRunTexture, Vec2 framesize, int frameorder[], int framenum, bool isrepeat) {
	for(int i=0;i < framenum ;i++) {
		SpriteFrame* frame = SpriteFrame::createWithTexture(playerRunTexture,
			Rect(framesize.x * frameorder[i], 0, framesize.x, framesize.y));
		animFrames.pushBack(frame); 
	}
	time = 0.3f;
	this -> isrepeat = isrepeat;
}
myAnimation* myAnimation::setSpeed(float time) {
	this->time = time;
	return this;
}
Action* myAnimation::getAnimation() {
	Animation* animation = Animation::createWithSpriteFrames(animFrames, time);
	Action* n;
	if(isrepeat) {
		n =  RepeatForever::create(Animate::create(animation));
	} else {
		n = Repeat::create(Animate::create(animation), 1);
	}
	return n;
}


