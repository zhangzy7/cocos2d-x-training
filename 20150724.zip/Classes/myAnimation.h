#include "cocos2d.h"
USING_NS_CC;
class myAnimation {
	public:
		Vector<SpriteFrame *> animFrames;
		float time;
		bool isrepeat;
		myAnimation() {};
		myAnimation(Texture2D* t, Vec2 framesize, int frameorder[], int framenum, bool isrepeat = true);
		myAnimation* setSpeed(float time);
		Action* getAnimation();
};