#include "GameLayer.h"
GameLayer::GameLayer() {
	this->scheduleUpdate();
}
GameLayer::~GameLayer() { }

bool GameLayer::init() {
	//TMX��ͼ
	_map = TMXTiledMap::create("img/bg/RoundFirst.tmx");
	CCSize winSize = CCDirector::sharedDirector()->getWinSize();
	locX = 0;
	//_map -> setScale(2);
	_wall = _map->layerNamed("walls");
	_hazard = _map->layerNamed("final");
	this -> addChild(_map, 1);
	//Ϊ��ͼ������������
	CreateBox();
	
	//����һ�����
	player = Actor::create();
	player->InitActorSprite("img/animation/elizabeth/png/$elizabeth_forward.png",Rect(0,0,66,74));
	player->setScale(0.6);
	player->setRotationY(180);
	player->setPosition(Vec2(64,160));
	player -> physicsbody -> setContactTestBitmask(1);
	player->setTag(PLAYER_TAG);
	this -> addChild(player, 2);


	//���̼�����
	auto listener = EventListenerKeyboard::create();
	listener->onKeyPressed = CC_CALLBACK_2(GameLayer::onKeyPressed, this);
	listener->onKeyReleased = CC_CALLBACK_2(GameLayer::onKeyReleased, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);

	//��ײ������
	auto physicslistener = EventListenerPhysicsContact::create();
	physicslistener->onContactBegin = CC_CALLBACK_1(GameLayer::onContactBegin, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(physicslistener, this);


	return true;
}
void GameLayer::onKeyPressed(EventKeyboard::KeyCode keyCode, Event* event) {
    if(EventKeyboard::KeyCode::KEY_D == keyCode) {
		log("D is pressed");
		player -> RunToRight();
	} else if(EventKeyboard::KeyCode::KEY_A == keyCode) {
		log("A is pressed");
		player -> RunToLeft();
	} else if(EventKeyboard::KeyCode::KEY_K == keyCode) {
		player -> Jump();
	} else if(EventKeyboard::KeyCode::KEY_J == keyCode) {
		player -> Attack();
	} else if(EventKeyboard::KeyCode::KEY_ESCAPE == keyCode) {
		Size visibleSize = Director::getInstance()->getVisibleSize();
		RenderTexture *renderTexture = CCRenderTexture::create(visibleSize.width,visibleSize.height);
		renderTexture->begin(); 
		this->getParent()->visit();
		renderTexture->end();
		Director::sharedDirector()->pushScene(GamePauseScene::createScene(renderTexture));
	}
}

void GameLayer::onKeyReleased(EventKeyboard::KeyCode keyCode, Event* event) {
	if((EventKeyboard::KeyCode::KEY_D == keyCode && player -> position == 1) ||
		(EventKeyboard::KeyCode::KEY_A == keyCode && player -> position == -1)) {
		player -> StopRunning();
	}
}

//��ײ���ص�����
bool GameLayer::onContactBegin(const PhysicsContact& contact) {
	auto spriteA = (Sprite*)contact.getShapeA()->getBody()->getNode();                 
    auto spriteB = (Sprite*)contact.getShapeB()->getBody()->getNode();
	auto data    = contact.getContactData() -> normal;
	if (spriteA && spriteB) {
		if((spriteA -> getTag() == PLAYER_TAG && spriteB -> getTag() == WALL_TAG) ||
			(spriteB -> getTag() == PLAYER_TAG && spriteA -> getTag() == WALL_TAG)) {
			if(data.y > 0.8 && data.y < 1.2)
				player -> onGround = true;
		}
		if((spriteA -> getTag() == PLAYER_TAG && spriteB -> getTag() == HAZARD_TAG) ||
			(spriteB -> getTag() == PLAYER_TAG && spriteA -> getTag() == HAZARD_TAG))
			   log("collision");
    }
	return true;
}

//ΪTMX��ͼ������������
void GameLayer::CreateBox() {
	log ("Map size: %f %f", _map->getMapSize().width, _map->getMapSize().height);
	for(int i=0; i < (int)(_map->getMapSize().width); i++) {
		for(int j=0; j < (int)(_map->getMapSize().height); j++) {
			auto tile = _wall->getTileAt(Vec2(i,j));
			//auto tile2 = _hazard->getTileAt(Vec2(i,j));
			if(tile) {
				CreateBoxForTile(tile, WALL_TAG);
			}
			/*
			if(tile2) {
				//CreateBoxForTile(tile2, HAZARD_TAG);
			}
			*/
		}
	}
}
//Ϊһ����Ƭ������������
void GameLayer::CreateBoxForTile(Sprite* tile, int tag) {
	
	tile -> setPositionX(tile -> getPositionX()+ tile -> getContentSize().width/2);
	tile -> setPositionY(tile -> getPositionY()+ tile -> getContentSize().height/2);
	tile -> setTag(tag);
	auto physicsbody = PhysicsBody::createEdgeBox(Size(_map->getTileSize().width,_map->getTileSize().height),
	PhysicsMaterial(0.0f, 0.0f, 0.0f));
	physicsbody -> setGravityEnable(false);
	physicsbody -> setDynamic(false);
	physicsbody->setContactTestBitmask(1);
	tile->setPhysicsBody(physicsbody);
	
}
//�ӵ����
void GameLayer::setViewpointCenter(cocos2d::Point pos, float dt) {
	
	Size visibleSize = Director::getInstance()->getVisibleSize();
	//�޶���ɫ���ܳ�������
	if(pos.x > visibleSize.width/2) {
		locX -= pos.x - visibleSize.width/2;
		float offset = locX;
		if(locX < visibleSize.width - _map->getMapSize().width * _map->getTileSize().width) {
			locX = visibleSize.width - _map->getMapSize().width * _map->getTileSize().width ;
		}
		offset = locX-offset;
		//�޶���ɫ�����ܳ���Ļ
		//�趨һ�µ�ͼ��λ��
		_map->setPositionX(locX);
		player -> setPositionX(visibleSize.width/2 + offset); 
		//if(abs(player->physicsbody->getVelocity().x) > player->VelocityX/2)
			//player->physicsbody->setVelocity(Vec2(player->physicsbody->getVelocity().x/2,player->physicsbody->getVelocity().y));
		//player->setPositionX(winSize.width/2);
	} else {

	}
	
	
}

void GameLayer::update(float dt) {
	this->setViewpointCenter(player->getPosition(), dt);
}




