#include "GamePauseScene.h"

Scene* GamePauseScene::createScene(RenderTexture* rt) {
	auto scene = Scene::create();;
    auto layer = GamePauseScene::create();
	Size visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();
	Sprite *_spr = Sprite::createWithTexture(rt->getSprite()->getTexture());  
	_spr->setPosition(Vec2(visibleSize.width/2 + origin.x, visibleSize.height/2 + origin.y));
	_spr->setFlipY(true);            //��ת����ΪUI�����OpenGL���겻ͬ
	_spr->setColor(ccc3(80, 80, 80)); //ͼƬ��ɫ���ɫ
	layer->addChild(_spr);
    scene->addChild(layer);
    return scene;
}
bool GamePauseScene::init() {
	//���̼�����
	auto listener = EventListenerKeyboard::create();
	listener->onKeyPressed = CC_CALLBACK_2(GamePauseScene::onKeyPressed, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);
	return true;
}

void GamePauseScene::onKeyPressed(EventKeyboard::KeyCode keyCode, Event* event) {
	if(EventKeyboard::KeyCode::KEY_ESCAPE == keyCode) {
		Director::sharedDirector()->popScene();
	}
}