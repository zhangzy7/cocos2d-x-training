#ifndef __TOOLS_H__
#define __TOOLS_H__
#include "cocos2d.h"
using namespace cocos2d;
class Tools {
	public:
		static Rect RectInset(Rect &rect, float dx, float dy);
		static Rect RectOffset(Rect &rect, Point);
		static Rect intersectsRect(Rect, Rect);
};
#endif